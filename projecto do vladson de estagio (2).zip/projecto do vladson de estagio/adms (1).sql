-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Tempo de geração: 20-Jan-2026 às 11:25
-- Versão do servidor: 10.4.32-MariaDB
-- versão do PHP: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Banco de dados: `adms`
--

-- --------------------------------------------------------

--
-- Estrutura da tabela `equipamentos`
--

CREATE TABLE `equipamentos` (
  `id` int(33) NOT NULL,
  `nome` varchar(255) NOT NULL,
  `tipo` varchar(255) NOT NULL,
  `data_registro` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `estado` enum('Funcional','Avariado') NOT NULL,
  `localização` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Extraindo dados da tabela `equipamentos`
--

INSERT INTO `equipamentos` (`id`, `nome`, `tipo`, `data_registro`, `estado`, `localização`) VALUES
(18, 'CPU', 'DISPOSITIVO ELECTRONICO', '2025-12-27 19:20:01', 'Avariado', 'LABORATORIO 23'),
(19, 'COMPUTADOR', 'DISPOSITIVO ELECTRONICO', '2026-01-05 13:22:59', 'Funcional', 'LABORATORIO 22'),
(22, 'COMPUTADOR', 'DISPOSITIVO ELECTRONICO', '2026-01-10 09:02:14', 'Avariado', 'LABORATORIO 5'),
(23, 'TELEFONE', 'DISPOSITIVO ELECTRONICO', '2026-01-10 09:02:49', 'Funcional', 'LABORATORIO 8'),
(24, 'DESKTOP', 'OBEJECTO', '2026-01-10 09:04:17', 'Funcional', 'LABORATORIO 8'),
(25, 'CANETA ', 'DISPOSITIVO', '2026-01-10 09:04:35', 'Funcional', 'LABORATORIO 8'),
(26, 'CANETA ', 'DISPOSITIVO', '2026-01-10 09:05:16', 'Funcional', 'LABORATORIO 8'),
(27, 'CANETA ', 'DISPOSITIVO', '2026-01-10 09:05:21', 'Funcional', 'LABORATORIO 8'),
(28, 'CANETA ', 'DISPOSITIVO', '2026-01-10 09:05:25', 'Funcional', 'LABORATORIO 8'),
(29, 'CANETA ', 'DISPOSITIVO', '2026-01-10 09:05:29', 'Funcional', 'LABORATORIO 8'),
(30, 'CANETA ', 'DISPOSITIVO', '2026-01-10 09:05:32', 'Funcional', 'LABORATORIO 8'),
(31, 'CANETA ', 'DISPOSITIVO', '2026-01-10 09:05:36', 'Funcional', 'LABORATORIO 8');

-- --------------------------------------------------------

--
-- Estrutura da tabela `users`
--

CREATE TABLE `users` (
  `id` int(33) NOT NULL,
  `nome` varchar(255) DEFAULT NULL,
  `senha` varchar(255) DEFAULT NULL,
  `email` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Extraindo dados da tabela `users`
--

INSERT INTO `users` (`id`, `nome`, `senha`, `email`) VALUES
(11, 'Lucas', '123', 'Lucas2@gmail.com'),
(12, 'Mauro', '123', 'Mauro2@gmail.com'),
(13, 'vladson', '123', 'vladsonsantos8@gmail.com');

--
-- Índices para tabelas despejadas
--

--
-- Índices para tabela `equipamentos`
--
ALTER TABLE `equipamentos`
  ADD PRIMARY KEY (`id`);

--
-- Índices para tabela `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT de tabelas despejadas
--

--
-- AUTO_INCREMENT de tabela `equipamentos`
--
ALTER TABLE `equipamentos`
  MODIFY `id` int(33) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=35;

--
-- AUTO_INCREMENT de tabela `users`
--
ALTER TABLE `users`
  MODIFY `id` int(33) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=14;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
