<?php 
include "db_conect.php";
session_start();
if(!isset($_SESSION["logado"]) || $_SESSION["logado"]==false){
    header("location:login.php");
exit();
}
?>
<?php
if(isset($_POST['btn'])){

    if($_SESSION["logado"]){
        $tipo = mysqli_real_escape_string($conn,($_POST['tipo']));
$estado = mysqli_real_escape_string($conn,($_POST['estado']));
$local = mysqli_real_escape_string($conn,($_POST['local']));
$nome = mysqli_real_escape_string($conn,($_POST['nome']));

$sql = "INSERT INTO equipamentos VALUES(DEFAULT,'$nome','$tipo',now(),'$estado','$local')";
$result=mysqli_query($conn,$sql);
    }


$sql="select id,nome from users";
$result=mysqli_query($conn,$sql);

        if(mysqli_num_rows($result)>0){
            $dados=mysqli_fetch_assoc($result);

            $_SESSION['adm'] = true;
            $_SESSION['id_usuario'] = $dados['id'];
            $_SESSION['nome_do_user']=$dados['nome'];
                 
            
        }else{
            header("location:registro.php");
            echo"<li>ERRO</li>";
        };
};
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Registro Adim</title>
    <style>
      
    * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }

       
        body {
             display: flex;
    align-items: center;
    justify-content: center;
    height: 100vh;
    overflow:hidden;
    flex-direction: row;
            font-family: 'Inter', system-ui, sans-serif;
            background: var(--background);
            color: var(--foreground);
            line-height: 1.6;
        } 
        :root {
            --background: #f5f6f8;
            --foreground: #0f172a;
            --card: #ffffff;
            --primary: #2563eb;
            --primary-light: #3b82f6;
            --primary-dark: #1d4ed8;
            --muted: #f1f5f9;
            --muted-foreground: #64748b;
            --border: #e2e8f0;
            --destructive: #ef4444;
            --success: #22c55e;
            --sidebar-bg: linear-gradient(180deg, #2563eb 0%, #1d4ed8 100%);
            --shadow-card: 0 10px 40px rgba(37, 99, 235, 0.08);
            --shadow-card-hover: 0 20px 50px rgba(37, 99, 235, 0.15);
            --gradient-primary: linear-gradient(135deg, #2563eb 0%, #3b82f6 100%);
            --radius: 12px;
        }


        /* Layout */
        .dashboard {
            display: flex;
            min-height: 100vh;
        }

        /* Sidebar */
        .sidebar {
            width: 260px;
            background: var(--sidebar-bg);
            color: white;
            display: flex;
            flex-direction: column;
            position: fixed;
            height: 100vh;
            transition: width 0.3s ease;
        }

        .sidebar.collapsed {
            width: 80px;
        }

        .sidebar-header {
            padding: 24px;
            display: flex;
            align-items: center;
            gap: 12px;
            border-bottom: 1px solid rgba(255,255,255,0.1);
        }

        .sidebar-logo {
            width: 40px;
            height: 40px;
            background: rgba(255,255,255,0.2);
            border-radius: 12px;
            display: flex;
            align-items: center;
            justify-content: center;
        }

        .sidebar-logo svg {
            width: 20px;
            height: 20px;
            stroke: white;
        }

        .sidebar-title {
            font-size: 18px;
            font-weight: 700;
        }

        .sidebar.collapsed .sidebar-title {
            display: none;
        }

        .sidebar-nav {
            flex: 1;
            padding: 16px;
        }

        .nav-link {
            display: flex;
            align-items: center;
            gap: 12px;
            padding: 14px 16px;
            color: rgba(255,255,255,0.8);
            text-decoration: none;
            border-radius: 10px;
            margin-bottom: 8px;
            transition: all 0.2s ease;
            font-size: 14px;
            font-weight: 500;
        }

        .nav-link:hover,
        .nav-link.active {
            background: rgba(255,255,255,0.15);
            color: white;
        }

        .nav-link svg {
            width: 20px;
            height: 20px;
            stroke: currentColor;
            flex-shrink: 0;
        }

        .sidebar.collapsed .nav-link span {
            display: none;
        }

        .sidebar.collapsed .nav-link {
            justify-content: center;
            padding: 14px;
        }

        .sidebar-footer {
            padding: 16px;
            border-top: 1px solid rgba(255,255,255,0.1);
        }

        .nav-link.logout:hover {
            background: rgba(239, 68, 68, 0.2);
        }

        /* Toggle Button */
        .sidebar-toggle {
            position: absolute;
            right: -12px;
            top: 32px;
            width: 24px;
            height: 24px;
            background: var(--primary);
            border: none;
            border-radius: 50%;
            color: white;
            cursor: pointer;
            display: flex;
            align-items: center;
            justify-content: center;
            box-shadow: 0 2px 8px rgba(0,0,0,0.2);
            transition: transform 0.2s;
            z-index: 10;
        }

        .sidebar-toggle:hover {
            transform: scale(1.1);
        }

        .sidebar-toggle svg {
            width: 14px;
            height: 14px;
        }

        /* Main Content */
        .main-content {
            flex: 1;
            margin-left: 260px;
            transition: margin-left 0.3s ease;
        }

        .sidebar.collapsed + .main-content {
            margin-left: 80px;
        }

        /* Header */
        .header {
            height: 64px;
            background: var(--card);
            border-bottom: 1px solid var(--border);
            display: flex;
            align-items: center;
            justify-content: space-between;
            padding: 0 24px;
            position: sticky;
            top: 0;
            z-index: 40;
        }

        .header-title {
            font-size: 20px;
            font-weight: 700;
        }

        .header-right {
            display: flex;
            align-items: center;
            gap: 16px;
        }

        .search-box {
            display: flex;
            align-items: center;
            gap: 8px;
            padding: 8px 16px;
            background: var(--muted);
            border-radius: 50px;
        }

        .search-box input {
            border: none;
            background: transparent;
            outline: none;
            font-size: 14px;
            width: 160px;
        }

        .search-box svg {
            width: 16px;
            height: 16px;
            stroke: var(--muted-foreground);
        }

        .notification-btn {
            position: relative;
            padding: 8px;
            background: transparent;
            border: none;
            border-radius: 50%;
            cursor: pointer;
            transition: background 0.2s;
        }

        .notification-btn:hover {
            background: var(--muted);
        }

        .notification-btn svg {
            width: 20px;
            height: 20px;
            stroke: var(--muted-foreground);
        }

        .notification-badge {
            position: absolute;
            top: 6px;
            right: 6px;
            width: 8px;
            height: 8px;
            background: var(--destructive);
            border-radius: 50%;
        }

        .user-menu {
            display: flex;
            align-items: center;
            gap: 12px;
            padding: 6px 16px 6px 6px;
            background: var(--primary);
            color: white;
            border-radius: 50px;
            cursor: pointer;
            border: none;
            transition: opacity 0.2s;
        }

        .user-menu:hover {
            opacity: 0.9;
        }

        .user-avatar {
            width: 32px;
            height: 32px;
            background: rgba(255,255,255,0.2);
            border-radius: 50%;
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 12px;
            font-weight: 600;
        }

        .user-name {
            font-size: 14px;
            font-weight: 500;
        }


  
    .conteudo{
        padding: 25px;
        height: calc(100vh - 60px);
        overflow-y: auto;
        display: flex;
        align-items: center;    
        justify-content: center;
    }


form{
    background-color:rgb(255, 255, 255);
   border-radius: 100px;
    width: 700px;
   box-shadow:0px 25px 50px -12px #6e749b40;
    height: 500px;
    margin: 7px;
    padding:20px 20px 20px 20px;
    border-radius: 10px;
    display: flex;
    flex-direction: column;
    gap: 10px;
    justify-content: center;
    animation:subir 3s ;
    
}
h1{
    align-self: center;
    font-weight: bolder;
    font-size: 40px;
}
span{
    color: rgb(30, 65, 173);
}
input{
    border: 2px solid;
    border-radius: 10px;
    padding: 20px;
}
input:hover{
    border: solid 2px rgb(30, 65, 173);
}
button{
   
   border-radius: 10px; 
   outline: none;
   padding: 20px;
   font-weight: bolder;
   color: white;
   background-color: rgb(30, 65, 173);
}
button:active{
    background-color: white;
    color: rgb(30, 65, 173);
}
#div1{
    display:flex;
    align-self:center;
width:300px;
}
#div2{
    display:flex;
    align-self:center; 
width:50%;
}

    .Btn {

  display: flex;
  align-items: center;
  justify-content: flex-start;
  width: 45px;
  height: 45px;
  border: none;
  border-radius: 50%;
  margin: auto;
    margin-left:20px;
  cursor: pointer;
  position: relative;
  overflow: hidden;
  transition-duration: .3s;
  box-shadow: 2px 2px 10px rgba(0, 0, 0, 0.199);
  background-color: rgb(0, 124, 255);

}

.sign {
  width: 100%;
  transition-duration: .3s;
  display: flex;
  align-items: center;
  justify-content: center;
}

.sign svg {
  width: 17px;
}

.sign svg path {
  fill: white;
}

.text {
  position: absolute;
  right: 0%;
  width: 0%;
  opacity: 0;
  color: white;
  font-size: 1.2em;
  font-weight: 600;
  transition-duration: .3s;
}

.Btn:hover {
  width: 150px;
  border-radius: 40px;
  transition-duration: .3s;
}

.Btn:hover .sign {
  width: 26%;
  transition-duration: .3s;
  padding-left: 10px;
}

.Btn:hover .text {
  opacity: 1;
  width: 70%;
  transition-duration: .3s;
  padding-right: 110px;
}

.Btn:active {
  transform: translate(2px ,2px);
}


    </style>
</head>
<html>
<body>




            <div class="dashboard">
        <!-- Sidebar -->
        <aside class="sidebar" id="sidebar">
           

            <div class="sidebar-header">
                <div class="sidebar-logo">
                    <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M20 7l-8-4-8 4m16 0l-8 4m8-4v10l-8 4m0-10L4 7m8 4v10M4 7v10l8 4" />
                    </svg>
                </div>
                <h1 class="sidebar-title">Inventário Escolar</h1>
            </div>

            <nav class="sidebar-nav">
                <a href="painel.php" class="nav-link active">
                    <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M4 5a1 1 0 011-1h14a1 1 0 011 1v2a1 1 0 01-1 1H5a1 1 0 01-1-1V5zM4 13a1 1 0 011-1h6a1 1 0 011 1v6a1 1 0 01-1 1H5a1 1 0 01-1-1v-6zM16 13a1 1 0 011-1h2a1 1 0 011 1v6a1 1 0 01-1 1h-2a1 1 0 01-1-1v-6z" />
                    </svg>
                    <span style="color: white;">Painel Inicial</span>
                </a>
                <a href="registroDeEquipamento.php" class="nav-link">
                    <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M20 7l-8-4-8 4m16 0l-8 4m8-4v10l-8 4m0-10L4 7m8 4v10M4 7v10l8 4" />
                    </svg>
                    <span  style="color: white;">Registrar Equipamento</span>
                </a>
                <a href="equipamentos.php" class="nav-link">
                    <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M4 6h16M4 10h16M4 14h16M4 18h16" />
                    </svg>
                    <span  style="color: white;">Lista de Equipamentos</span>
                </a>
                <a href="definição.php" class="nav-link">
                    <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M10.325 4.317c.426-1.756 2.924-1.756 3.35 0a1.724 1.724 0 002.573 1.066c1.543-.94 3.31.826 2.37 2.37a1.724 1.724 0 001.065 2.572c1.756.426 1.756 2.924 0 3.35a1.724 1.724 0 00-1.066 2.573c.94 1.543-.826 3.31-2.37 2.37a1.724 1.724 0 00-2.572 1.065c-.426 1.756-2.924 1.756-3.35 0a1.724 1.724 0 00-2.573-1.066c-1.543.94-3.31-.826-2.37-2.37a1.724 1.724 0 00-1.065-2.572c-1.756-.426-1.756-2.924 0-3.35a1.724 1.724 0 001.066-2.573c-.94-1.543.826-3.31 2.37-2.37.996.608 2.296.07 2.572-1.065z" />
                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M15 12a3 3 0 11-6 0 3 3 0 016 0z" />
                    </svg>
                    <span  style="color: white;">Definições</span>
                </a>
                <a href="registro.php" class="nav-link">
                    <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M18 9v3m0 0v3m0-3h3m-3 0h-3m-2-5a4 4 0 11-8 0 4 4 0 018 0zM3 20a6 6 0 0112 0v1H3v-1z" />
                    </svg>
                    <span  style="color: white;">Registrar Administrador</span>
                </a>
            </nav>

            <div class="sidebar-footer">
                <a href="logout.php" class="nav-link logout">
                    <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M17 16l4-4m0 0l-4-4m4 4H7m6 4v1a3 3 0 01-3 3H6a3 3 0 01-3-3V7a3 3 0 013-3h4a3 3 0 013 3v1" />
                    </svg>
                    <span  style="color: white;">Desconectar</span>
                </a>
            </div>
        </aside>
    </div>



        <!-- Main Content -->
        <div class="main-content">
            <!-- Header -->
            <header class="header">
                <h1 class="header-title">Registro de equipamentos</h1>
                <div class="header-right">
                    <button class="notification-btn">
                        <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M15 17h5l-1.405-1.405A2.032 2.032 0 0118 14.158V11a6.002 6.002 0 00-4-5.659V5a2 2 0 10-4 0v.341C7.67 6.165 6 8.388 6 11v3.159c0 .538-.214 1.055-.595 1.436L4 17h5m6 0v1a3 3 0 11-6 0v-1m6 0H9" />
                        </svg>
                        <span class="notification-badge"></span>
                    </button>
                    <button class="user-menu">
                        <div class="user-avatar"> <?php echo $_SESSION["nome_do_user"][0]; ?></div>
                        <span class="user-name"  style="color: white;"> <?php echo $_SESSION["nome_do_user"]; ?></span>
                    </button>
                </div>
            </header>
           

    <div class="conteudo">
 <form method="post" action="<?php echo $_SERVER['PHP_SELF'];?>">

    <label for="">nome do Equipamento</label>
    <input type="text" name="nome" placeholder="nome" required>

    <label for="">Tipo de equipamento</label>
    <input type="text" name="tipo"  placeholder="tipo" required>

    <label for="">Estado</label>
    <input type="text" name="estado" placeholder="Funcional/Avariado" required>

     <label for="">Local</label>
    <input type="text" name="local" placeholder="localizaçaõ" required>

    <button type="submit" name="btn" style="background-color:#1d4ed8; ;">ADD</button>
   </form>
    </div>
</div>




</body>
</html>