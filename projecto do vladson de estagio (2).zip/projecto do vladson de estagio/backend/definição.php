
<?php
include 'db_conect.php';
session_start();
if(!isset($_SESSION["logado"]) || $_SESSION["logado"]==false){
    header("location:login.php");
exit();
};


  $sql = "SELECT id,nome,email FROM users";
            $result = mysqli_query($conn, $sql);
        if(mysqli_num_rows($result) > 0)
                    $dados = mysqli_fetch_array($result);
                $_SESSION['logado'] = true;
                $_SESSION['id_usuario'] = $dados['id'];
                $_SESSION['nome_do_user']=$dados['nome'];
                 $_SESSION['email_user']=$dados['email'];


?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
     <style>

    * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }

       
        body {
            font-family: 'Inter', system-ui, sans-serif;
            background: var(--background);
            color: var(--foreground);
            line-height: 1.6;
        } 
        :root {
            --background: #f5f6f8;
            --foreground: #0f172a;
            --card: #ffffff;
            --primary: #2563eb;
            --primary-light: #3b82f6;
            --primary-dark: #1d4ed8;
            --muted: #f1f5f9;
            --muted-foreground: #64748b;
            --border: #e2e8f0;
            --destructive: #ef4444;
            --success: #22c55e;
            --sidebar-bg: linear-gradient(180deg, #2563eb 0%, #1d4ed8 100%);
            --shadow-card: 0 10px 40px rgba(37, 99, 235, 0.08);
            --shadow-card-hover: 0 20px 50px rgba(37, 99, 235, 0.15);
            --gradient-primary: linear-gradient(135deg, #2563eb 0%, #3b82f6 100%);
            --radius: 12px;
        }


        /* Layout */
        .dashboard {
            display: flex;
            min-height: 100vh;
        }

        /* Sidebar */
        .sidebar {
            width: 260px;
            background: var(--sidebar-bg);
            color: white;
            display: flex;
            flex-direction: column;
            position: fixed;
            height: 100vh;
            transition: width 0.3s ease;
        }

        .sidebar.collapsed {
            width: 80px;
        }

        .sidebar-header {
            padding: 24px;
            display: flex;
            align-items: center;
            gap: 12px;
            border-bottom: 1px solid rgba(255,255,255,0.1);
        }

        .sidebar-logo {
            width: 40px;
            height: 40px;
            background: rgba(255,255,255,0.2);
            border-radius: 12px;
            display: flex;
            align-items: center;
            justify-content: center;
        }

        .sidebar-logo svg {
            width: 20px;
            height: 20px;
            stroke: white;
        }

        .sidebar-title {
            font-size: 18px;
            font-weight: 700;
        }

        .sidebar.collapsed .sidebar-title {
            display: none;
        }

        .sidebar-nav {
            flex: 1;
            padding: 16px;
        }

        .nav-link {
            display: flex;
            align-items: center;
            gap: 12px;
            padding: 14px 16px;
            color: rgba(255,255,255,0.8);
            text-decoration: none;
            border-radius: 10px;
            margin-bottom: 8px;
            transition: all 0.2s ease;
            font-size: 14px;
            font-weight: 500;
        }

        .nav-link:hover,
        .nav-link.active {
            background: rgba(255,255,255,0.15);
            color: white;
        }

        .nav-link svg {
            width: 20px;
            height: 20px;
            stroke: currentColor;
            flex-shrink: 0;
        }

        .sidebar.collapsed .nav-link span {
            display: none;
        }

        .sidebar.collapsed .nav-link {
            justify-content: center;
            padding: 14px;
        }

        .sidebar-footer {
            padding: 16px;
            border-top: 1px solid rgba(255,255,255,0.1);
        }

        .nav-link.logout:hover {
            background: rgba(239, 68, 68, 0.2);
        }

        /* Toggle Button */
        .sidebar-toggle {
            position: absolute;
            right: -12px;
            top: 32px;
            width: 24px;
            height: 24px;
            background: var(--primary);
            border: none;
            border-radius: 50%;
            color: white;
            cursor: pointer;
            display: flex;
            align-items: center;
            justify-content: center;
            box-shadow: 0 2px 8px rgba(0,0,0,0.2);
            transition: transform 0.2s;
            z-index: 10;
        }

        .sidebar-toggle:hover {
            transform: scale(1.1);
        }

        .sidebar-toggle svg {
            width: 14px;
            height: 14px;
        }

        /* Main Content */
        .main-content {
            flex: 1;
            margin-left: 260px;
            transition: margin-left 0.3s ease;
        }

        .sidebar.collapsed + .main-content {
            margin-left: 80px;
        }

        /* Header */
        .header {
            height: 64px;
            background: var(--card);
            border-bottom: 1px solid var(--border);
            display: flex;
            align-items: center;
            justify-content: space-between;
            padding: 0 24px;
            position: sticky;
            top: 0;
            z-index: 40;
        }

        .header-title {
            font-size: 20px;
            font-weight: 700;
        }

        .header-right {
            display: flex;
            align-items: center;
            gap: 16px;
        }

        .search-box {
            display: flex;
            align-items: center;
            gap: 8px;
            padding: 8px 16px;
            background: var(--muted);
            border-radius: 50px;
        }

        .search-box input {
            border: none;
            background: transparent;
            outline: none;
            font-size: 14px;
            width: 160px;
        }

        .search-box svg {
            width: 16px;
            height: 16px;
            stroke: var(--muted-foreground);
        }

        .notification-btn {
            position: relative;
            padding: 8px;
            background: transparent;
            border: none;
            border-radius: 50%;
            cursor: pointer;
            transition: background 0.2s;
        }

        .notification-btn:hover {
            background: var(--muted);
        }

        .notification-btn svg {
            width: 20px;
            height: 20px;
            stroke: var(--muted-foreground);
        }

        .notification-badge {
            position: absolute;
            top: 6px;
            right: 6px;
            width: 8px;
            height: 8px;
            background: var(--destructive);
            border-radius: 50%;
        }

        .user-menu {
            display: flex;
            align-items: center;
            gap: 12px;
            padding: 6px 16px 6px 6px;
            background: var(--primary);
            color: white;
            border-radius: 50px;
            cursor: pointer;
            border: none;
            transition: opacity 0.2s;
        }

        .user-menu:hover {
            opacity: 0.9;
        }

        .user-avatar {
            width: 32px;
            height: 32px;
            background: rgba(255,255,255,0.2);
            border-radius: 50%;
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 12px;
            font-weight: 600;
        }

        .user-name {
            font-size: 14px;
            font-weight: 500;
        }

        /* Page Content */
        .page-content {
            padding: 24px;
        }

        /* Stats Grid */
        .stats-grid {
            display: grid;
            grid-template-columns: repeat(4, 1fr);
            gap: 24px;
            margin-bottom: 32px;
        }

        @media (max-width: 1200px) {
            .stats-grid {
                grid-template-columns: repeat(2, 1fr);
            }
        }

        @media (max-width: 768px) {
            .stats-grid {
                grid-template-columns: 1fr;
            }
        }

        .stat-card {
            background: var(--card);
            border-radius: var(--radius);
            padding: 24px;
            border: 1px solid rgba(226, 232, 240, 0.5);
            box-shadow: var(--shadow-card);
            transition: all 0.3s ease;
        }

        .stat-card:hover {
            box-shadow: var(--shadow-card-hover);
            transform: translateY(-2px);
        }

        .stat-card-content {
            display: flex;
            justify-content: space-between;
            align-items: flex-start;
        }

        .stat-label {
            font-size: 14px;
            font-weight: 500;
            color: var(--muted-foreground);
        }

        .stat-value {
            font-size: 32px;
            font-weight: 700;
            margin-top: 8px;
        }

        .stat-trend {
            font-size: 14px;
            font-weight: 500;
            margin-top: 8px;
        }

        .stat-trend.positive {
            color: var(--success);
        }

        .stat-trend.negative {
            color: var(--destructive);
        }

        .stat-trend span {
            color: var(--muted-foreground);
            margin-left: 4px;
        }

        .stat-icon {
            width: 48px;
            height: 48px;
            background: rgba(37, 99, 235, 0.1);
            border-radius: 12px;
            display: flex;
            align-items: center;
            justify-content: center;
        }

        .stat-icon svg {
            width: 24px;
            height: 24px;
            stroke: var(--primary);
        }

        /* Section Header */
        .section-header {
            display: flex;
            align-items: center;
            gap: 12px;
            margin-bottom: 24px;
        }

        .section-icon {
            width: 40px;
            height: 40px;
            background: rgba(37, 99, 235, 0.1);
            border-radius: 12px;
            display: flex;
            align-items: center;
            justify-content: center;
        }

        .section-icon svg {
            width: 20px;
            height: 20px;
            stroke: var(--primary);
        }

        .section-title {
            font-size: 24px;
            font-weight: 700;
        }

        /* Profile Card */
        .profile-card {
            background: linear-gradient(145deg, #ffffff 0%, #f8fafc 100%);
            border-radius: 16px;
            padding: 24px;
            max-width: 600px;
             margin-left: 20px;
            box-shadow: var(--shadow-card);
            border: 1px solid rgba(226, 232, 240, 0.3);
            animation: fadeIn 0.3s ease-out;
        }

        @keyframes fadeIn {
            from {
                opacity: 0;
                transform: translateY(10px);
            }
            to {
                opacity: 1;
                transform: translateY(0);
            }
        }

        .profile-card-content {
            display: flex;
            align-items: center;
            gap: 20px;
        }

        .profile-avatar {
            width: 64px;
            height: 64px;
            background: var(--gradient-primary);
            border-radius: 50%;
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 20px;
            font-weight: 700;
            color: white;
            flex-shrink: 0;
        }

        .profile-info {
            flex: 1;
            min-width: 0;
        }

        .profile-name {
            font-size: 18px;
            font-weight: 600;
            margin-bottom: 4px;
        }

        .profile-email {
            display: flex;
            align-items: center;
            gap: 8px;
            color: var(--primary);
            font-size: 14px;
            margin-bottom: 4px;
        }

        .profile-email svg {
            width: 16px;
            height: 16px;
            stroke: currentColor;
        }

        .profile-department {
            display: flex;
            align-items: center;
            gap: 8px;
            color: var(--muted-foreground);
            font-size: 14px;
            font-style: italic;
        }

        .profile-department svg {
            width: 16px;
            height: 16px;
            stroke: currentColor;
        }

        .profile-actions {
            display: flex;
            flex-direction: column;
            gap: 8px;
        }

        /* Buttons */
        .btn {
            display: inline-flex;
            align-items: center;
            justify-content: center;
            gap: 8px;
            padding: 10px 24px;
            border-radius: 50px;
            font-size: 14px;
            font-weight: 600;
            border: none;
            cursor: pointer;
            transition: all 0.3s ease;
            text-decoration: none;
        }

        .btn svg {
            width: 16px;
            height: 16px;
            stroke: currentColor;
        }

        .btn-primary {
            background: var(--gradient-primary);
            color: white;
        }

        .btn-primary:hover {
            opacity: 0.9;
            transform: scale(1.05);
        }

        .btn-danger {
            background: var(--destructive);
            color: white;
        }

        .btn-danger:hover {
            opacity: 0.9;
            transform: scale(1.05);
        }

        .btn-outline {
            background: transparent;
            border: 2px solid var(--border);
            color: var(--muted-foreground);
        }

        .btn-outline:hover {
            background: var(--muted);
        }

        /* Modal */
        .modal-overlay {
            display: none;
            position: fixed;
            inset: 0;
            background: rgba(15, 23, 42, 0.6);
            backdrop-filter: blur(4px);
            justify-content: center;
            align-items: center;
            z-index: 1000;
        }

        .modal-overlay.active {
            display: flex;
        }

        .modal {
            background: var(--card);
            border-radius: 16px;
            padding: 24px;
            width: 100%;
            height: 600px;
            max-width: 400px;
            box-shadow: 0 25px 50px -12px rgba(0, 0, 0, 0.25);
           
            animation: scaleIn 0.3s ease-out;
        }

        @keyframes scaleIn {
            from {
                opacity: 0;
                transform: scale(0.95);
            }
            to {
                opacity: 1;
                transform: scale(1);
            }
        }

        .modal-header {
            display: flex;
            align-items: center;
            justify-content: space-between;
            padding-bottom: 16px;
            border-bottom: 1px solid var(--border);
        }

        .modal-title {
            font-size: 20px;
            font-weight: 700;
        }

        .modal-close {
            width: 36px;
            height: 36px;
            background: transparent;
            border: none;
            border-radius: 50%;
            cursor: pointer;
            display: flex;
            align-items: center;
            justify-content: center;
            transition: background 0.2s;
        }

        .modal-close:hover {
            background: var(--muted);
        }

        .modal-close svg {
            width: 20px;
            height: 20px;
            stroke: var(--muted-foreground);
        }

        .modal-body {
            padding: 24px 0;
        }

        .form-group {
            margin-bottom: 16px;
        }

        .form-label {
            display: flex;
            align-items: center;
            gap: 8px;
            font-size: 14px;
            font-weight: 500;
            margin-bottom: 8px;
        }

        .form-label svg {
            width: 16px;
            height: 16px;
            stroke: var(--primary);
        }

        .form-input {
            width: 100%;
            padding: 12px 16px;
            border: 2px solid var(--border);
            border-radius: 12px;
            font-size: 14px;
            transition: all 0.2s;
            background: var(--background);
        }

        .form-input:focus {
            outline: none;
            border-color: var(--primary);
            box-shadow: 0 0 0 3px rgba(37, 99, 235, 0.1);
        }

        .modal-actions {
            display: flex;
            gap: 12px;
        }

        .modal-actions .btn {
            flex: 1;
        }

        /* Delete Modal */
        .modal-icon {
            width: 64px;
            height: 64px;
            background: rgba(239, 68, 68, 0.1);
            border-radius: 50%;
            display: flex;
            align-items: center;
            justify-content: center;
            margin: 0 auto 16px;
        }

        .modal-icon svg {
            width: 32px;
            height: 32px;
            stroke: var(--destructive);
        }

        .modal-centered {
            text-align: center;
            height: 300px;
        }

        .modal-message {
            color: var(--muted-foreground);
            margin-bottom: 24px;
        }

        /* Responsive */
        @media (max-width: 768px) {
            .sidebar {
                transform: translateX(-100%);
            }

            .sidebar.open {
                transform: translateX(0);
            }

            .main-content {
                margin-left: 0;
            }

            .header-right .search-box,
            .user-name {
                display: none;
            }

            .profile-card-content {
                flex-direction: column;
                text-align: center;
            }

            .profile-actions {
                width: 100%;
            }
        }


.cartao-email {
  display: flex;
  align-items: center;
  gap: 16px;
  padding: 20px 24px;
  border-radius: 16px;
  transition: all 0.3s ease;
  width: 60%;
  margin-top: 50px;
  margin-left: 50px;
}


.cartao-professor {
  background: linear-gradient(145deg, #ffffff 0%, #f8f9ff 100%);
  box-shadow: 0 10px 40px rgba(0, 0, 0, 0.15);
  border: 2px solid rgba(255, 255, 255, 0.8);
}



.avatar-email {
  width: 56px;
  height: 56px;
  border-radius: 50%;
  display: flex;
  align-items: center;
  justify-content: center;
  font-size: 1.4rem;
  font-weight: 700;
  color: #ffffffff;
  flex-shrink: 0;
}

.avatar-professor {
  width: 64px;
  height: 64px;
  background: #2d558a;
  font-size: 1.6rem;
 
}


.conteudo-email {
  flex: 1;
  min-width: 0;
  
}

.nome-email {
  font-size: 1.1rem;
  font-weight: 600;
  color: #2d3748;
  margin-bottom: 4px;
}

.endereco-email {
  font-size: 0.95rem;
  color: #667eea;
  margin-bottom: 4px;
  word-break: break-all;
}

.departamento-email {
  font-size: 0.85rem;
  color: #718096;
  font-style: italic;
}


.botao-acao {
  background: #2d558a;
  color: #ffffff;
  border: none;
  padding: 10px 20px;
  border-radius: 25px;
  font-size: 0.95rem;
  font-weight: 600;
  cursor: pointer;
  transition: all 0.3s ease;
 
}

.botao-acao:hover {
  transform: scale(1.05);
 
}






        .fundo-modal2 {
        display: none; /* Oculto por padrão */
        position: fixed;
        top: 0; left: 0;
        width: 100%; height: 100%;
        background: rgba(0, 0, 0, 0.6);
        backdrop-filter: blur(3px);
        justify-content: center;
        align-items: center;
        z-index: 1000;
    }

    /* ===== Caixa do modal ===== */
    .caixa-modal2 {
        position: relative;
        left: 50%;top: 50%;
        transform: translate(-50%, -50%);
        background: white;
        padding: 20px;
        border-radius: 10px;
        max-width: 400px;
        width: 90%;
        box-shadow: 0 5px 15px rgba(0,0,0,0.3);
        animation: aparecer 0.3s ease;
    }

    /* ===== Cabeçalho do modal ===== */
    .cabecalho-modal2 {
        display: flex;
        justify-content: space-between;
        align-items: center;
        border-bottom: 1px solid #ddd;
        padding-bottom: 10px;
    }
    .cabecalho-modal2 h2 {
        margin: 0;
        font-size: 20px;
    }
    .botao-fechar2 {
       height:40px;
       margin-left: 40px;
        background: #1e27e1ff;
        color: white;
        border: none;
        border-radius: 20px;
        width: 150px;
        cursor: pointer;
        font-size: 16px;
        transition: background 0.3s;
    }
    .botao-fechar2:hover {
        color: #f5f3f3ff;
        background: #1e28e1a7;
    }

    /* ===== Corpo do modal ===== */
    .corpo-modal2 {
        margin-top: 15px;
        font-size: 16px;
        color: #333;
        height: 400px;
    }


        .fundo-modal {
        display: none; /* Oculto por padrão */
        position: fixed;
        top: 0; left: 0;
        width: 100%; height: 100%;
        background: rgba(0, 0, 0, 0.6);
        backdrop-filter: blur(3px);
        justify-content: center;
        align-items: center;
        z-index: 1000;
    }

    /* ===== Caixa do modal ===== */
    .caixa-modal {
        position: relative;
        left: 50%;top: 50%;
        transform: translate(-50%, -50%);
        background: white;
        padding: 20px;
        border-radius: 10px;
        max-width: 400px;
        width: 90%;
        box-shadow: 0 5px 15px rgba(0,0,0,0.3);
        animation: aparecer 0.3s ease;
    }

    /* ===== Cabeçalho do modal ===== */
    .cabecalho-modal {
        display: flex;
        justify-content: space-between;
        align-items: center;
        border-bottom: 1px solid #ddd;
        padding-bottom: 10px;
    }
    .cabecalho-modal h2 {
        margin: 0;
        font-size: 20px;
    }
    .botao-fechar {
       height:40px;
       margin-left: 40px;
        background: #1e27e1ff;
        color: white;
        border: none;
        border-radius: 20px;
        width: 150px;
        cursor: pointer;
        font-size: 16px;
        transition: background 0.3s;
    }
    .botao-fechar:hover {
        color: #f5f3f3ff;
        background: #1e28e1a7;
    }

    /* ===== Corpo do modal ===== */
    .corpo-modal {
        margin-top: 15px;
        font-size: 16px;
        color: #333;
        height: 400px;
    }

    /* ===== Animação ===== */
    @keyframes aparecer {
        from { opacity: 0; transform: translateY(-20px); }
        to { opacity: 1; transform: translateY(0); }
    }
     .salvarB  {
        height:40px;
        margin-left: 10px;
        background: #1114b7bd;
        color: white;
        border: none;
        border-radius: 20px;
        width: 150px;
        cursor: pointer;
        font-size: 16px;
        transition: background 0.3s;
    }
      .salvarB  {
       background: #0f11bd83;  
    }
    .botao-fechar {
        height:40px;
        background: #e01d1dff;
        color: white;
        border: none;
        border-radius: 20px;
        width: 150px;
        cursor: pointer;
        font-size: 16px;
        transition: background 0.3s;
    }
    .botao-fechar:hover {
       background: #e01d1d83;  
    }
    input{
    border: 2px solid;
    border-radius: 10px;
    padding: 20px;
    width: 350px;
}
input:hover{
    border: solid 2px rgb(30, 65, 173);
}
form{
    width: 100%;
    height: 100%;
    display: flex;
    align-items: center;
    justify-content: center;
    flex-direction: column;
    gap: 10px;
}


     </style>
</head>
<body>
    
<div class="fundo-modal" id="fundoModal">
    <div class="caixa-modal">
        <div class="cabecalho-modal">
            <h2>Editar Informações</h2>
        </div>
        <div class="corpo-modal">
          <form method="post" action="editarInfoUser.php">
    
    <input type="text" name="nome" placeholder="nome" required>

    
    <input type="email" name="email" placeholder="email" required>


    <input type="password" name="pass"  placeholder="password" required>

    <input type="password" name="passConfirm"  placeholder="new password" required>
    <?php
    if(isset($_SESSION["erros"])){
        foreach($_SESSION["erros"] as $erro){
            echo $erro;
        }
        unset($_SESSION['erros']);
    }
    ?>
    </form>
    </div>
    <div style="display: flex; flex-direction:row;">
    <button name="salvar" class="salvarB" type="submit">salvar</button>
        <button class="botao-fechar" id="fecharModal" type="button">voltar</button>
    </div>
    
        </div>
    </div>
</div>



<div class="fundo-modal2" id="fundoModal2">
    <div class="caixa-modal2">
        <div class="cabecalho-modal2">
            <h2>deseja realmente deletar?</h2>
        </div>
    <button id="deleta"  style="background-color: red;height:40px;
        margin-left: 10px;
        color: white;
        border: none;
        border-radius: 20px;
        width: 150px;
        cursor: pointer;
        font-size: 16px;
        transition: background 0.3s;" type="submit" onclick="executar()">deletar</button>
        <button class="botao-fechar2" id="fecharModal2" type="button">voltar</button>
    </div>
        </div>
   




            <div class="dashboard">
        <!-- Sidebar -->
        <aside class="sidebar" id="sidebar">
           

            <div class="sidebar-header">
                <div class="sidebar-logo">
                    <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M20 7l-8-4-8 4m16 0l-8 4m8-4v10l-8 4m0-10L4 7m8 4v10M4 7v10l8 4" />
                    </svg>
                </div>
                <h1 class="sidebar-title">Inventário Escolar</h1>
            </div>

            <nav class="sidebar-nav">
                <a href="painel.php" class="nav-link active">
                    <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M4 5a1 1 0 011-1h14a1 1 0 011 1v2a1 1 0 01-1 1H5a1 1 0 01-1-1V5zM4 13a1 1 0 011-1h6a1 1 0 011 1v6a1 1 0 01-1 1H5a1 1 0 01-1-1v-6zM16 13a1 1 0 011-1h2a1 1 0 011 1v6a1 1 0 01-1 1h-2a1 1 0 01-1-1v-6z" />
                    </svg>
                    <span>Painel Inicial</span>
                </a>
                <a href="registroDeEquipamento.php" class="nav-link">
                    <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M20 7l-8-4-8 4m16 0l-8 4m8-4v10l-8 4m0-10L4 7m8 4v10M4 7v10l8 4" />
                    </svg>
                    <span>Registrar Equipamento</span>
                </a>
                <a href="equipamentos.php" class="nav-link">
                    <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M4 6h16M4 10h16M4 14h16M4 18h16" />
                    </svg>
                    <span>Lista de Equipamentos</span>
                </a>
                <a href="definição.php" class="nav-link">
                    <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M10.325 4.317c.426-1.756 2.924-1.756 3.35 0a1.724 1.724 0 002.573 1.066c1.543-.94 3.31.826 2.37 2.37a1.724 1.724 0 001.065 2.572c1.756.426 1.756 2.924 0 3.35a1.724 1.724 0 00-1.066 2.573c.94 1.543-.826 3.31-2.37 2.37a1.724 1.724 0 00-2.572 1.065c-.426 1.756-2.924 1.756-3.35 0a1.724 1.724 0 00-2.573-1.066c-1.543.94-3.31-.826-2.37-2.37a1.724 1.724 0 00-1.065-2.572c-1.756-.426-1.756-2.924 0-3.35a1.724 1.724 0 001.066-2.573c-.94-1.543.826-3.31 2.37-2.37.996.608 2.296.07 2.572-1.065z" />
                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M15 12a3 3 0 11-6 0 3 3 0 016 0z" />
                    </svg>
                    <span>Definições</span>
                </a>
                <a href="registro.php" class="nav-link">
                    <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M18 9v3m0 0v3m0-3h3m-3 0h-3m-2-5a4 4 0 11-8 0 4 4 0 018 0zM3 20a6 6 0 0112 0v1H3v-1z" />
                    </svg>
                    <span>Registrar Administrador</span>
                </a>
            </nav>

            <div class="sidebar-footer">
                <a href="logout.php" class="nav-link logout">
                    <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M17 16l4-4m0 0l-4-4m4 4H7m6 4v1a3 3 0 01-3 3H6a3 3 0 01-3-3V7a3 3 0 013-3h4a3 3 0 013 3v1" />
                    </svg>
                    <span>Desconectar</span>
                </a>
            </div>
        </aside>
        
        <!-- Main Content -->
        <div class="main-content">
            <!-- Header -->
            <header class="header">
                <h1 class="header-title">Definições do Usuário</h1>
                <div class="header-right">
                    <button class="notification-btn">
                        <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M15 17h5l-1.405-1.405A2.032 2.032 0 0118 14.158V11a6.002 6.002 0 00-4-5.659V5a2 2 0 10-4 0v.341C7.67 6.165 6 8.388 6 11v3.159c0 .538-.214 1.055-.595 1.436L4 17h5m6 0v1a3 3 0 11-6 0v-1m6 0H9" />
                        </svg>
                        <span class="notification-badge"></span>
                    </button>
                    <button class="user-menu">
                        <div class="user-avatar"> <?php echo $_SESSION["nome_do_user"][0]; ?></div>
                        <span class="user-name"  style="color: white;"> <?php echo $_SESSION["nome_do_user"]; ?></span>
                    </button>
                </div>
            </header>
           

          <br><br>
                <!-- Profile Card -->
                <div class="profile-card">
                    <div class="profile-card-content">
                        <div class="profile-avatar"> <?php echo $_SESSION["nome_do_user"][0]; ?></div>
                        <div class="profile-info">
                            <h3 class="profile-name"> <?php echo $_SESSION["nome_do_user"]; ?></h3>
                            <div class="profile-email">
                                <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M3 8l7.89 5.26a2 2 0 002.22 0L21 8M5 19h14a2 2 0 002-2V7a2 2 0 00-2-2H5a2 2 0 00-2 2v10a2 2 0 002 2z" />
                                </svg>
                                <?php echo $_SESSION["email_user"]; ?>
                            </div>
                            <div class="profile-department">
                                <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M21 13.255A23.931 23.931 0 0112 15c-3.183 0-6.22-.62-9-1.745M16 6V4a2 2 0 00-2-2h-4a2 2 0 00-2 2v2m4 6h.01M5 20h14a2 2 0 002-2V8a2 2 0 00-2-2H5a2 2 0 00-2 2v10a2 2 0 002 2z" />
                                </svg>
                                Administrador
                            </div>
                        </div>
                        <div class="profile-actions">
                            <button class="btn btn-primary" onclick="openEditModal()">
                                <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M11 5H6a2 2 0 00-2 2v11a2 2 0 002 2h11a2 2 0 002-2v-5m-1.414-9.414a2 2 0 112.828 2.828L11.828 15H9v-2.828l8.586-8.586z" />
                                </svg>
                                Editar
                            </button>

                         <?php if(mysqli_num_rows($result)>1){ 
            echo "<button class='btn btn-danger' onclick='openDeleteModal()'>
                                <svg xmlns='http://www.w3.org/2000/svg' fill='none' viewBox='0 0 24 24' stroke='currentColor'>
                                    <path stroke-linecap='round' stroke-linejoin='round' stroke-width='2' d='M19 7l-.867 12.142A2 2 0 0116.138 21H7.862a2 2 0 01-1.995-1.858L5 7m5 4v6m4-6v6m1-10V4a1 1 0 00-1-1h-4a1 1 0 00-1 1v3M4 7h16' />
                                </svg>
                                Deletar
                            </button>"; }else{
                
             }?>



                            
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
  

                <!-- Settings Section -->
                <div class="section-header">
                    <div class="section-icon">
                        <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M10.325 4.317c.426-1.756 2.924-1.756 3.35 0a1.724 1.724 0 002.573 1.066c1.543-.94 3.31.826 2.37 2.37a1.724 1.724 0 001.065 2.572c1.756.426 1.756 2.924 0 3.35a1.724 1.724 0 00-1.066 2.573c.94 1.543-.826 3.31-2.37 2.37a1.724 1.724 0 00-2.572 1.065c-.426 1.756-2.924 1.756-3.35 0a1.724 1.724 0 00-2.573-1.066c-1.543.94-3.31-.826-2.37-2.37a1.724 1.724 0 00-1.065-2.572c-1.756-.426-1.756-2.924 0-3.35a1.724 1.724 0 001.066-2.573c-.94-1.543.826-3.31 2.37-2.37.996.608 2.296.07 2.572-1.065z" />
                            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M15 12a3 3 0 11-6 0 3 3 0 016 0z" />
                        </svg>
                    </div>
                    <h2 class="section-title">Definições do User</h2>
                </div>




    <form action="editarInfoUser.php" method="post">

 <!-- Edit Modal -->
    <div class="modal-overlay" id="editModal">
        <div class="modal">
            <div class="modal-header">
                <h2 class="modal-title">Editar Informações</h2>
               
            </div>
            <div class="modal-body">
                <div class="form-group">
                    <label class="form-label">
                        <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M16 7a4 4 0 11-8 0 4 4 0 018 0zM12 14a7 7 0 00-7 7h14a7 7 0 00-7-7z" />
                        </svg>
                        Nome
                    </label>
                    <input type="text" name="nome" class="form-input" placeholder="Digite seu nome" value=<?php echo $_SESSION["nome_do_user"]; ?>>
                </div>
                <div class="form-group">
                    <label class="form-label">
                        <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M3 8l7.89 5.26a2 2 0 002.22 0L21 8M5 19h14a2 2 0 002-2V7a2 2 0 00-2-2H5a2 2 0 00-2 2v10a2 2 0 002 2z" />
                        </svg>
                        Email
                    </label>
                    <input type="email" name="email" class="form-input" placeholder="Digite seu email" value=<?php echo $_SESSION["email_user"]; ?>>
                </div>
                <div class="form-group">
                    <label class="form-label">
                        <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 15v2m-6 4h12a2 2 0 002-2v-6a2 2 0 00-2-2H6a2 2 0 00-2 2v6a2 2 0 002 2zm10-10V7a4 4 0 00-8 0v4h8z" />
                        </svg>
                        Nova Senha (opcional)
                    </label>
                    <input type="password" name="pass" class="form-input" placeholder="Digite uma nova senha">
                </div>
            <div class="form-group">
                    <label class="form-label">
                        <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 15v2m-6 4h12a2 2 0 002-2v-6a2 2 0 00-2-2H6a2 2 0 00-2 2v6a2 2 0 002 2zm10-10V7a4 4 0 00-8 0v4h8z" />
                        </svg>
                        confirmar
                    </label>
                    <input type="password" name="passConfirm" class="form-input" placeholder="Digite uma nova senha">
                </div>

            <div class="modal-actions">
                <button class="btn btn-primary">
                    <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M8 7H5a2 2 0 00-2 2v9a2 2 0 002 2h14a2 2 0 002-2V9a2 2 0 00-2-2h-3m-1 4l-3 3m0 0l-3-3m3 3V4" />
                    </svg>
                    Salvar
                </button>
                <button type="submit" name="salvar" class="btn btn-outline" onclick="closeEditModal()">Voltar</button>
            </div>
        </div>
    </div>
    </div>
    </form>



   
    <!-- Delete Modal -->
    <div class="modal-overlay" id="deleteModal">
        <div class="modal modal-centered">
            <div class="modal-icon">
                <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 9v2m0 4h.01m-6.938 4h13.856c1.54 0 2.502-1.667 1.732-3L13.732 4c-.77-1.333-2.694-1.333-3.464 0L3.34 16c-.77 1.333.192 3 1.732 3z" />
                </svg>
            </div>
            <h2 class="modal-title">Deseja realmente deletar?</h2>
            <p class="modal-message">Esta ação não pode ser desfeita.</p>
            <div class="modal-actions">
                <button class="btn btn-danger" onclick="executar()">
                    <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" id="deleta" d="M19 7l-.867 12.142A2 2 0 0116.138 21H7.862a2 2 0 01-1.995-1.858L5 7m5 4v6m4-6v6m1-10V4a1 1 0 00-1-1h-4a1 1 0 00-1 1v3M4 7h16" />
                    </svg>
                    Deletar
                </button>
                <button class="btn btn-outline" onclick="closeDeleteModal()">Voltar</button>
            </div>
        </div>
    </div>





</body>
</html>
<script>
     function toggleSidebar() {
            document.getElementById('sidebar').classList.toggle('collapsed');
        }

        function openEditModal() {
            document.getElementById('editModal').classList.add('active');
        }

        function closeEditModal() {
            document.getElementById('editModal').classList.remove('active');
        }

        function openDeleteModal() {
            document.getElementById('deleteModal').classList.add('active');
        }

        function closeDeleteModal() {
            document.getElementById('deleteModal').classList.remove('active');
        }

        // Close modals when clicking outside
        document.querySelectorAll('.modal-overlay').forEach(overlay => {
            overlay.addEventListener('click', function(e) {
                if (e.target === this) {
                    this.classList.remove('active');
                }
            });
        });

    function executar(){
        fetch("deletarUser.php")
        .then(resposta=> resposta.text())
        .then(dados => {
        document.getElementById("deleta").innerHTML=dados;
            location.reload();
            window.location.href="login.php";
        })
    }
   
</script>
 <?php if(isset($_SESSION['erros'])){ ?>
<script>
    document.getElementById('fundoModal').style.display = 'block';
</script>
<?php }; ?>