
<?php
include 'db_conect.php';
session_start();

if(isset($_POST['btn'])){
  
    $erros = array();
    $email = mysqli_real_escape_string($conn,($_POST['email']));
    $senha = mysqli_real_escape_string($conn,($_POST['pass']));

    if(empty($senha) or empty($email)){
        $erros[] = "<li style='list-style-type:none;font-size:11px; color:red;'>O campo email/senha precisa ser preenchido</li>";
    } else {
        $sql = "SELECT * FROM users WHERE email='$email'";
        $result = mysqli_query($conn,$sql);

  
        if(mysqli_num_rows($result) > 0){
       
            $sql = "SELECT id,nome,email FROM users WHERE senha='$senha' AND email='$email'";
            $result = mysqli_query($conn, $sql);

            if(mysqli_num_rows($result) == 1){
  
                $dados = mysqli_fetch_array($result);
                $_SESSION['logado'] = true;
                $_SESSION['id_usuario'] = $dados['id'];
                $_SESSION['nome_do_user']=$dados['nome'];
                 $_SESSION['email_user']=$dados['email'];
                 
                header('location:painel.php');
                exit();
            } else {
                $erros[] = "<li style='list-style-type:none; font-size:11px; color:red;>Usuário e senha não coincidem</li>";
            }
        } else {
            $erros[] = "<li style='list-style-type:none; font-size:11px; color:red;'>Usuário inexistente</li>";
        }
    }
}
?>





<!DOCTYPE html>
<html lang="pt-BR">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Login</title>
  <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700&display=swap" rel="stylesheet">
  <style>
    * {
      margin: 0;
      padding: 0;
      box-sizing: border-box;
    }

    body {
      font-family: 'Inter', sans-serif;
      min-height: 100vh;
      background-color: #ffffff;
      color: #0f172a;
    }

    .container {
      display: flex;
      min-height: 100vh;
    }

    /* Decorative Panel */
    .decorative-panel {
      display: none;
      width: 50%;
      background: linear-gradient(to bottom right, rgba(99, 102, 241, 0.05), rgba(168, 85, 247, 0.05), rgba(99, 102, 241, 0.1));
      position: relative;
      overflow: hidden;
      padding: 3rem;
    }

    @media (min-width: 1024px) {
      .decorative-panel {
        display: flex;
        flex-direction: column;
        justify-content: center;
      }
    }

    .grid-pattern {
      position: absolute;
      inset: 0;
      background-image: 
        linear-gradient(rgba(99, 102, 241, 0.03) 1px, transparent 1px),
        linear-gradient(90deg, rgba(99, 102, 241, 0.03) 1px, transparent 1px);
      background-size: 50px 50px;
    }

    .orb {
      position: absolute;
      border-radius: 50%;
      filter: blur(80px);
      animation: float 6s ease-in-out infinite;
    }

    .orb-1 {
      width: 400px;
      height: 400px;
      background: linear-gradient(to bottom right, rgba(99, 102, 241, 0.3), rgba(168, 85, 247, 0.2));
      top: -100px;
      right: -100px;
    }

    .orb-2 {
      width: 300px;
      height: 300px;
      background: linear-gradient(to bottom right, rgba(168, 85, 247, 0.2), rgba(236, 72, 153, 0.2));
      bottom: -50px;
      left: -50px;
      animation-delay: -3s;
    }

    @keyframes float {
      0%, 100% { transform: translateY(0); }
      50% { transform: translateY(-20px); }
    }

    .panel-content {
      position: relative;
      z-index: 10;
      max-width: 500px;
      margin: 0 auto;
    }

    .panel-content h1 {
      font-size: 3rem;
      font-weight: 700;
      margin-bottom: 1.5rem;
      background: linear-gradient(to right, #6366f1, #a855f7);
      -webkit-background-clip: text;
      -webkit-text-fill-color: transparent;
      background-clip: text;
    }

    .panel-content p {
      font-size: 1.125rem;
      color: #64748b;
      margin-bottom: 3rem;
    }

    .features {
      display: flex;
      flex-direction: column;
      gap: 1.5rem;
    }

    .feature {
      display: flex;
      align-items: center;
      gap: 1rem;
    }

    .feature-icon {
      width: 48px;
      height: 48px;
      background: linear-gradient(135deg, rgba(99, 102, 241, 0.1), rgba(168, 85, 247, 0.1));
      border-radius: 12px;
      display: flex;
      align-items: center;
      justify-content: center;
    }

    .feature-icon svg {
      width: 24px;
      height: 24px;
      color: #6366f1;
    }

    .feature-text h3 {
      font-weight: 600;
      color: #0f172a;
    }

    .feature-text p {
      font-size: 0.875rem;
      color: #64748b;
      margin: 0;
    }

    /* Login Form Section */
    .form-section {
      width: 100%;
      display: flex;
      align-items: center;
      justify-content: center;
      padding: 2rem;
      background-color: #ffffff;
    }

    @media (min-width: 1024px) {
      .form-section {
        width: 50%;
      }
    }

    .form-container {
      width: 100%;
      max-width: 420px;
    }

    .logo {
      width: 56px;
      height: 56px;
      background: linear-gradient(135deg, #6366f1, #a855f7);
      border-radius: 16px;
      display: flex;
      align-items: center;
      justify-content: center;
      margin-bottom: 2rem;
      box-shadow: 0 10px 40px -10px rgba(99, 102, 241, 0.4);
    }

    .logo svg {
      width: 32px;
      height: 32px;
      color: white;
    }

    .form-header h2 {
      font-size: 1.875rem;
      font-weight: 700;
      color: #0f172a;
      margin-bottom: 0.5rem;
    }

    .form-header p {
      color: #64748b;
      margin-bottom: 2rem;
    }

    .form-group {
      margin-bottom: 1.5rem;
    }

    .form-group label {
      display: block;
      font-size: 0.875rem;
      font-weight: 500;
      color: #0f172a;
      margin-bottom: 0.5rem;
    }

    .input-wrapper {
      position: relative;
    }

    .input-wrapper svg {
      position: absolute;
      left: 1rem;
      top: 50%;
      transform: translateY(-50%);
      width: 20px;
      height: 20px;
      color: #94a3b8;
    }

    .input-wrapper input {
      width: 100%;
      height: 48px;
      padding: 0 1rem 0 3rem;
      border: 1px solid #e2e8f0;
      border-radius: 12px;
      font-size: 1rem;
      background-color: #f8fafc;
      color: #0f172a;
      transition: all 0.2s;
    }

    .input-wrapper input:focus {
      outline: none;
      border-color: #6366f1;
      box-shadow: 0 0 0 3px rgba(99, 102, 241, 0.1);
    }

    .input-wrapper input::placeholder {
      color: #94a3b8;
    }

    .input-wrapper .toggle-password {
      position: absolute;
      right: 1rem;
      top: 50%;
      transform: translateY(-50%);
      background: none;
      border: none;
      cursor: pointer;
      color: #94a3b8;
      transition: color 0.2s;
    }

    .input-wrapper .toggle-password:hover {
      color: #0f172a;
    }

    .form-options {
      display: flex;
      justify-content: space-between;
      align-items: center;
      margin-bottom: 1.5rem;
    }

    .remember-me {
      display: flex;
      align-items: center;
      gap: 0.5rem;
    }

    .remember-me input[type="checkbox"] {
      width: 18px;
      height: 18px;
      accent-color: #6366f1;
      cursor: pointer;
    }

    .remember-me label {
      font-size: 0.875rem;
      color: #64748b;
      cursor: pointer;
    }

    .forgot-password {
      font-size: 0.875rem;
      color: #6366f1;
      text-decoration: none;
      transition: color 0.2s;
    }

    .forgot-password:hover {
      color: #4f46e5;
    }

    .btn-primary {
      width: 100%;
      height: 48px;
      background-color: rgb(30, 65, 173);
      color: white;
      border: none;
      border-radius: 12px;
      font-size: 1rem;
      font-weight: 600;
      cursor: pointer;
      transition: opacity 0.2s;
      box-shadow: 0 10px 40px -10px rgba(99, 102, 241, 0.4);
    }

    .btn-primary:hover {
      opacity: 0.9;
    }

    .divider {
      display: flex;
      align-items: center;
      margin: 1.5rem 0;
    }

    .divider::before,
    .divider::after {
      content: '';
      flex: 1;
      height: 1px;
      background-color: #e2e8f0;
    }

    .divider span {
      padding: 0 1rem;
      font-size: 0.75rem;
      color: #94a3b8;
      text-transform: uppercase;
      background-color: #ffffff;
    }

    .social-buttons {
      display: grid;
      grid-template-columns: 1fr 1fr;
      gap: 1rem;
      margin-bottom: 1.5rem;
    }

    .btn-social {
      height: 48px;
      display: flex;
      align-items: center;
      justify-content: center;
      gap: 0.5rem;
      background-color: #f8fafc;
      border: 1px solid #e2e8f0;
      border-radius: 12px;
      font-size: 0.875rem;
      font-weight: 500;
      color: #0f172a;
      cursor: pointer;
      transition: background-color 0.2s;
    }

    .btn-social:hover {
      background-color: #f1f5f9;
    }

    .btn-social svg {
      width: 20px;
      height: 20px;
    }

    .signup-link {
      text-align: center;
      font-size: 0.875rem;
      color: #64748b;
    }

    .signup-link a {
      color: #6366f1;
      text-decoration: none;
      font-weight: 500;
      transition: color 0.2s;
    }

    .signup-link a:hover {
      color: #4f46e5;
    }
  </style>
</head>
<body>
  <div class="container">
    
    <div class="decorative-panel">
      <div class="grid-pattern"></div>
      <div class="orb orb-1"></div>
      <div class="orb orb-2"></div>
      
      <div class="panel-content">
        <h1>Bem-vindo de volta</h1>
        <p>Acesse sua conta para continuar sua jornada e explorar todas as funcionalidades como administrador.</p>
        
        <div class="features">
          <div class="feature">
            <div class="feature-icon">
              <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke="currentColor" stroke-width="2">
                <path stroke-linecap="round" stroke-linejoin="round" d="M9 12.75L11.25 15 15 9.75m-3-7.036A11.959 11.959 0 013.598 6 11.99 11.99 0 003 9.749c0 5.592 3.824 10.29 9 11.623 5.176-1.332 9-6.03 9-11.622 0-1.31-.21-2.571-.598-3.751h-.152c-3.196 0-6.1-1.248-8.25-3.285z" />
              </svg>
            </div>
            <div class="feature-text">
              <h3>Protege seus equipamentos de uma forma mais avançada</h3>
              <p>Seus dados protegidos com criptografia</p>
            </div>
          </div>
          
          <div class="feature">
            <div class="feature-icon">
              <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke="currentColor" stroke-width="2">
                <path stroke-linecap="round" stroke-linejoin="round" d="M3.75 13.5l10.5-11.25L12 10.5h8.25L9.75 21.75 12 13.5H3.75z" />
              </svg>
            </div>
            <div class="feature-text">
              <h3>Performance Rápida</h3>
              <p>Interface otimizada para velocidade</p>
            </div>
          </div>
          
          <div class="feature">
            <div class="feature-icon">
              <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke="currentColor" stroke-width="2">
                <path stroke-linecap="round" stroke-linejoin="round" d="M9.813 15.904L9 18.75l-.813-2.846a4.5 4.5 0 00-3.09-3.09L2.25 12l2.846-.813a4.5 4.5 0 003.09-3.09L9 5.25l.813 2.846a4.5 4.5 0 003.09 3.09L15.75 12l-2.846.813a4.5 4.5 0 00-3.09 3.09zM18.259 8.715L18 9.75l-.259-1.035a3.375 3.375 0 00-2.455-2.456L14.25 6l1.036-.259a3.375 3.375 0 002.455-2.456L18 2.25l.259 1.035a3.375 3.375 0 002.456 2.456L21.75 6l-1.035.259a3.375 3.375 0 00-2.456 2.456z" />
              </svg>
            </div>
            <div class="feature-text">
              <h3>Design Moderno</h3>
              <p>Experiência visual elegante</p>
            </div>
          </div>
        </div>
      </div>
    </div>

    <!-- Login Form -->
    <div class="form-section">
      <div class="form-container">
       

        <div class="form-header">
          <h2>Entre na sua conta</h2>
          <p>Digite suas credenciais para acessar</p>
        </div>

        <form method="POST" action="<?php echo $_SERVER['PHP_SELF']; ?>">
             <?php
    if(!empty($erros)){
        foreach($erros as $erro){
            echo $erro;
        };
    };
    ?>
          <div class="form-group">
            <label for="email">Email</label>
            <div class="input-wrapper">
              <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke="currentColor" stroke-width="2">
                <path stroke-linecap="round" stroke-linejoin="round" d="M21.75 6.75v10.5a2.25 2.25 0 01-2.25 2.25h-15a2.25 2.25 0 01-2.25-2.25V6.75m19.5 0A2.25 2.25 0 0019.5 4.5h-15a2.25 2.25 0 00-2.25 2.25m19.5 0v.243a2.25 2.25 0 01-1.07 1.916l-7.5 4.615a2.25 2.25 0 01-2.36 0L3.32 8.91a2.25 2.25 0 01-1.07-1.916V6.75" />
              </svg>
              <input type="email" id="email" name="email" placeholder="seu@email.com" autocomplemente="email" required>
            </div>
          </div>

          <div class="form-group">
            <label for="password">Senha</label>
            <div class="input-wrapper">
              <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke="currentColor" stroke-width="2">
                <path stroke-linecap="round" stroke-linejoin="round" d="M16.5 10.5V6.75a4.5 4.5 0 10-9 0v3.75m-.75 11.25h10.5a2.25 2.25 0 002.25-2.25v-6.75a2.25 2.25 0 00-2.25-2.25H6.75a2.25 2.25 0 00-2.25 2.25v6.75a2.25 2.25 0 002.25 2.25z" />
              </svg>
              <input type="password" id="password" name="pass" placeholder="••••••••" autocomplemente="curret-password" required>
              <button type="button" class="toggle-password" onclick="togglePassword()">
                <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke="currentColor" stroke-width="2">
                </svg>
              </button>
            </div>
          </div>

          <div class="form-options">
            <div class="remember-me">
              <input type="checkbox" id="remember">
              <label for="remember">Lembrar de mim</label>
            </div>
            <a href="#" class="forgot-password">Esqueceu a senha?</a>
          </div>

          <button type="submit" class="btn-primary" name="btn">Entrar</button>
        </form>

        <div class="divider">
          <span>ou continue com</span>
        </div>

        <div class="social-buttons">
          <button type="button" class="btn-social">
            <svg viewBox="0 0 24 24">
              <path fill="#4285F4" d="M22.56 12.25c0-.78-.07-1.53-.2-2.25H12v4.26h5.92c-.26 1.37-1.04 2.53-2.21 3.31v2.77h3.57c2.08-1.92 3.28-4.74 3.28-8.09z"/>
              <path fill="#34A853" d="M12 23c2.97 0 5.46-.98 7.28-2.66l-3.57-2.77c-.98.66-2.23 1.06-3.71 1.06-2.86 0-5.29-1.93-6.16-4.53H2.18v2.84C3.99 20.53 7.7 23 12 23z"/>
              <path fill="#FBBC05" d="M5.84 14.09c-.22-.66-.35-1.36-.35-2.09s.13-1.43.35-2.09V7.07H2.18C1.43 8.55 1 10.22 1 12s.43 3.45 1.18 4.93l2.85-2.22.81-.62z"/>
              <path fill="#EA4335" d="M12 5.38c1.62 0 3.06.56 4.21 1.64l3.15-3.15C17.45 2.09 14.97 1 12 1 7.7 1 3.99 3.47 2.18 7.07l3.66 2.84c.87-2.6 3.3-4.53 6.16-4.53z"/>
            </svg>
            Google
          </button>
          <button type="button" class="btn-social">
            <svg fill="currentColor" viewBox="0 0 24 24">
              <path d="M12 0c-6.626 0-12 5.373-12 12 0 5.302 3.438 9.8 8.207 11.387.599.111.793-.261.793-.577v-2.234c-3.338.726-4.033-1.416-4.033-1.416-.546-1.387-1.333-1.756-1.333-1.756-1.089-.745.083-.729.083-.729 1.205.084 1.839 1.237 1.839 1.237 1.07 1.834 2.807 1.304 3.492.997.107-.775.418-1.305.762-1.604-2.665-.305-5.467-1.334-5.467-5.931 0-1.311.469-2.381 1.236-3.221-.124-.303-.535-1.524.117-3.176 0 0 1.008-.322 3.301 1.23.957-.266 1.983-.399 3.003-.404 1.02.005 2.047.138 3.006.404 2.291-1.552 3.297-1.23 3.297-1.23.653 1.653.242 2.874.118 3.176.77.84 1.235 1.911 1.235 3.221 0 4.609-2.807 5.624-5.479 5.921.43.372.823 1.102.823 2.222v3.293c0 .319.192.694.801.576 4.765-1.589 8.199-6.086 8.199-11.386 0-6.627-5.373-12-12-12z"/>
            </svg>
            GitHub
          </button>
        </div>

       
      </div>
    </div>
  </div>

  <script>
    function togglePassword() {
      const passwordInput = document.getElementById('password');
      passwordInput.type = passwordInput.type === 'password' ? 'text' : 'password';
    }
  </script>
</body>
</html>
