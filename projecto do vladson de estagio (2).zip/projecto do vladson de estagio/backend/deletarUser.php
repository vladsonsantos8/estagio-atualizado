<?php
include 'db_conect.php';
session_start();


function deletar($conn){
if(isset($_SESSION["logado"])){
    $sql="SELECT id,nome,email FROM users ORDER BY id DESC";
    $result=mysqli_query($conn,$sql);
}

    $id=$_SESSION["id_usuario"];
    $sql="DELETE from users WHERE id=$id";
    $result=mysqli_query($conn,$sql);
    return $result;
    
}
$resultado4=deletar($conn);

?>