<?php
include 'db_conect.php';
session_start();


if(isset($_SESSION["logado"]) && isset($_POST["btn"])){
$tipo = mysqli_real_escape_string($conn,($_POST['tipo']));
$estado = mysqli_real_escape_string($conn,($_POST['estado']));
$local = mysqli_real_escape_string($conn,($_POST['local']));
$nome = mysqli_real_escape_string($conn,($_POST['nome']));

    $sql="SELECT id,nome,tipo,data_registro,estado,localização FROM Equipamentos ORDER BY id DESC";
    $result=mysqli_query($conn,$sql);

  if(mysqli_num_rows($result)>0){
    $dados=mysqli_fetch_assoc($result);
    $id=$dados["id"];

     $sql="UPDATE equipamentos SET nome='$nome',tipo='$tipo',estado='$estado', localização='$local'  WHERE id=$id"; 
  
    $result=mysqli_query($conn,$sql);
    header("location:equipamentos.php");
  }
}else{
  echo"erro";
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Document</title>
</head>
<body>
</body>
</html>
