
<?php
include 'db_conect.php';
session_start();
if(!isset($_SESSION["logado"]) || $_SESSION["logado"]==false){
    header("location:login.php");
exit();
};


if(isset($_SESSION["logado"])){
    $sql="SELECT id,nome,tipo,data_registro,estado,localização FROM Equipamentos ORDER BY id DESC";
    $result=mysqli_query($conn,$sql);
}
function contarEquipamentos($conn){
    $sql="SELECT COUNT(nome) AS total_equipamentos from equipamentos";
    $result=mysqli_query($conn,$sql);
    return $result;
}


function contarAvariados($conn){
    $sql="SELECT COUNT(*) AS total_avariados from equipamentos where estado='avariado'";
    $result=mysqli_query($conn,$sql);
    return $result;
}
function contarFuncionais($conn){
    $sql="SELECT COUNT(*) AS total_funcionais from equipamentos where estado='Funcional'";
    $result=mysqli_query($conn,$sql);
    return $result;
}
$resultado=contarEquipamentos($conn);
$resultado2=contarAvariados($conn);
$resultado3=contarFuncionais($conn);


?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css">
     <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css">
    <title>Document</title>
     <style>
        *{
        margin: 0;
        padding: 0;
        box-sizing: border-box;
        font-family: "Segoe UI", Arial, sans-serif;
    }
    body{
        background: #F4F6F8;
        display: flex;
        height: 100vh;
        overflow: hidden;
    }

   
    .barra-lateral{
        width: 260px;
        background: #2d558a;
        color: white;
        padding: 25px 20px;
        display: flex;
        flex-direction: column;
    }

    .barra-lateral-titulo{
        font-size: 22px;
        font-weight: bold;
        margin-bottom: 40px;
        text-align: center;
    }

    .menu-lateral a{
        text-decoration: none;
        color: white;
        padding: 14px 15px;
        display: block;
        margin-bottom: 12px;
        background: rgba(255,255,255,0.15);
        border-radius: 6px;
        transition: 0.25s;
        font-size: 15px;
    }

    .menu-lateral a:hover{
        background: #2d558a;
    }

    .area-principal{
        flex: 1;
        display: flex;
        flex-direction: column;
        height: 100%;
        overflow: hidden;
    }

    .cabecalho{
        background: white;
        height: 60px;
        display: flex;
        align-items: center;
        padding: 0 25px;
        border-bottom: 1px solid #D0D4D8;
        justify-content: space-between;
    }

    .cabecalho-titulo{
        font-size: 20px;
        font-weight: bold;
        color: #333333;
    }

    .caixa-usuario{
        background: #2d558a;
        padding: 8px 14px;
        border-radius: 50px;
        color: white;
        font-size: 14px;
        cursor: pointer;
    }

  
    .conteudo{
        padding: 25px;
        height: calc(100vh - 60px);
        overflow-y: auto;
    }

  
    .caixas-info{
        display: flex;
        gap: 20px;
        margin-bottom: 25px;
    }

    .caixa-info{
        flex: 1;
        background: white;
        border: 1px solid #D0D4D8;
        padding: 20px;
        border-radius: 8px;
        box-shadow: 0 1px 3px rgba(0,0,0,0.08);
    }

    .caixa-info h3{
        font-size: 16px;
        color: #333333;
        margin-bottom: 8px;
    }

    .caixa-info span{
        font-size: 26px;
        font-weight: bold;
    }

    table{
        width: 100%;
        border-collapse: collapse;
        background: white;
        border-radius: 6px;
        overflow: hidden;
        box-shadow: 0 1px 3px rgba(0,0,0,0.12);
    }

    th{
    background: #2d558a;
        color: white;
        padding: 11px;
        text-align: left;
        font-size: 15px;
    }

    td{
        padding: 12px;
        font-size: 14px;
        color: #333333;
        border-bottom: 1px solid #D0D4D8;
    }

    tr:hover{
        background: #F0F7FF;
    }

    .estado-funcional{
        color: #34A853;
        font-weight: bold;
    }

    .estado-avariado{
        color: #EA4335;
        font-weight: bold;
    }


    .Btn {

  display: flex;
  align-items: center;
  justify-content: flex-start;
  width: 45px;
  height: 45px;
  border: none;
  border-radius: 50%;
  margin: auto;
    margin-left:20px;
  cursor: pointer;
  position: relative;
  overflow: hidden;
  transition-duration: .3s;
  box-shadow: 2px 2px 10px rgba(0, 0, 0, 0.199);
  background-color: rgb(0, 124, 255);

}

.sign {
  width: 100%;
  transition-duration: .3s;
  display: flex;
  align-items: center;
  justify-content: center;
}

.sign svg {
  width: 17px;
}

.sign svg path {
  fill: white;
}

.text {
  position: absolute;
  right: 0%;
  width: 0%;
  opacity: 0;
  color: white;
  font-size: 1.2em;
  font-weight: 600;
  transition-duration: .3s;
}

.Btn:hover {
  width: 150px;
  border-radius: 40px;
  transition-duration: .3s;
}

.Btn:hover .sign {
  width: 26%;
  transition-duration: .3s;
  padding-left: 10px;
}

.Btn:hover .text {
  opacity: 1;
  width: 70%;
  transition-duration: .3s;
  padding-right: 110px;
}

.Btn:active {
  transform: translate(2px ,2px);
}

 .edit-icon {
    margin-left:5px;
            font-size: 15px; 
            color: #007bff;  
            cursor: pointer;
        }
        .edit-icon:hover {
            color: #0056b3; 
        }



        .fundo-modal {
        display: none; /* Oculto por padrão */
        position: fixed;
        top: 0; left: 0;
        width: 100%; height: 100%;
        background: rgba(0, 0, 0, 0.6);
        backdrop-filter: blur(3px);
        justify-content: center;
        align-items: center;
        z-index: 1000;
    }

    /* ===== Caixa do modal ===== */
    .caixa-modal {
        position: relative;
        left: 50%;top: 50%;
        transform: translate(-50%, -50%);
        background: white;
        padding: 20px;
        border-radius: 10px;
        max-width: 400px;
        width: 90%;
        box-shadow: 0 5px 15px rgba(0,0,0,0.3);
        animation: aparecer 0.3s ease;
    }

    /* ===== Cabeçalho do modal ===== */
    .cabecalho-modal {
        display: flex;
        justify-content: space-between;
        align-items: center;
        border-bottom: 1px solid #ddd;
        padding-bottom: 10px;
    }
    .cabecalho-modal h2 {
        margin: 0;
        font-size: 20px;
    }
    .botao-fechar {
       height:40px;
        background: #1e27e1ff;
        color: white;
        border: none;
        border-radius: 20px;
        width: 150px;
        cursor: pointer;
        font-size: 16px;
        transition: background 0.3s;
    }
    .botao-fechar:hover {
        color: #f5f3f3ff;
        background: #1e28e1a7;
    }

    /* ===== Corpo do modal ===== */
    .corpo-modal {
        margin-top: 15px;
        font-size: 16px;
        color: #333;
    }

    /* ===== Animação ===== */
    @keyframes aparecer {
        from { opacity: 0; transform: translateY(-20px); }
        to { opacity: 1; transform: translateY(0); }
    }
     button {
        height:40px;
        background: #e01d1dff;
        color: white;
        border: none;
        border-radius: 20px;
        width: 150px;
        cursor: pointer;
        font-size: 16px;
        transition: background 0.3s;
    }
    button:hover {
       background: #e01d1d83;  
    }

        
     </style>
</head>
<body>

<div class="fundo-modal" id="fundoModal">
    <div class="caixa-modal">
        <div class="cabecalho-modal">
            <h2>Deletar equipamento</h2>
            
        </div>
        <div class="corpo-modal">
           Tem certeza que deseja deletar este equipamento?
        </div>
        <button id="deletar" onclick="executar()">deletar</button>
        <button class="botao-fechar" id="fecharModal">voltar</button>
       
    </div>
</div>
<div class="barra-lateral">
    <h2 class="barra-lateral-titulo">Inventário Escolar</h2>

    <div class="menu-lateral">
        <a href="painel.php"> Painel Inicial</a>
        <a href="registroDeEquipamento.php"> Registar Equipamento</a>
        <a href="equipamentos.php"> Lista de Equipamentos</a>
        <a href="definição.php"> Definições</a>      
        <a href="registro.php">Registrar Administrador</a>
        <a href="logout.php">Desconectar</a>
    
    </div>
</div>

<div class="area-principal">


    <div class="cabecalho">
        <div class="cabecalho-titulo">Lista de Equipamentos</div>
        <div class="caixa-usuario"><?php echo $_SESSION['nome_do_user'] ?></div>
    </div>

    <div class="conteudo">

        <table>
            <tr>
               <th>nome</th>
                <th>tipo</th>
                 <th>estado</th>
                  <th>local</th>
                     <th>data</th>
                      <th>opções</th>
            </tr>

    <?php if(mysqli_num_rows($result)>0){ ?>
        <?php while($date=mysqli_fetch_assoc($result)){ ?> 
            <tr> 
                <td><?php echo $date["nome"];?></td>
                <td><?php echo $date["tipo"];?></td>
                <td class="estado-funcional">
                    
                    <?php 
                if($date["estado"]=="Funcional"){
                    echo "<span class='estado-funcional' style='color:green'>FUNCIONAL</span>";
               
                }else{
                    echo "<span class='estado-avariado' style='color:red'>AVARIADO</span>";
                }
                ?>
                </td>
                <td><?php echo $date["localização"]; ?></td>
                <td><?php echo $date["data_registro"]; ?></td>   
                 <td id="delete"  ><i class="fa-solid fa-trash" style="color:red;"></i>  <i id="editar" class="fa-solid fa-pencil edit-icon"></i> </td>  
                </tr>
<?php }; ?>
<?php }; ?>

        </table>

    </div>
</div>
</body>
</html>
<script>
    const botaoAbrir = document.getElementById('delete');
    const botaoFechar = document.getElementById('fecharModal');
    const fundoModal = document.getElementById('fundoModal');
    
   

    // Abre o modal
    botaoAbrir.addEventListener('click', () => {
        fundoModal.style.display = 'block'; 
        
    });

    // Fecha o modal
    botaoFechar.addEventListener('click', () => {
        fundoModal.style.display = 'none';
    });

    // Fecha clicando fora da caixa
    window.addEventListener('click', (evento) => {
        if (evento.target === fundoModal) {
            fundoModal.style.display = 'none';
        }
    });
 
    function executar(){
        fetch("deletar.php")
        .then(resposta=> resposta.text())
        .then(dados => {
        document.getElementById("deletar").innerHTML=dados;
            location.reload();
        })
    }
</script>