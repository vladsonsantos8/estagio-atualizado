
<?php
include 'db_conect.php';
session_start();
if(!isset($_SESSION["logado"]) || $_SESSION["logado"]==false){
    header("location:login.php");
exit();
};


if(isset($_SESSION["logado"])){
    $sql="SELECT id,nome,tipo,data_registro,estado,localização FROM Equipamentos ORDER BY id DESC";
    $result=mysqli_query($conn,$sql);
}
function contarEquipamentos($conn){
    $sql="SELECT COUNT(nome) AS total_equipamentos from equipamentos";
    $result=mysqli_query($conn,$sql);
    return $result;
}


function contarAvariados($conn){
    $sql="SELECT COUNT(*) AS total_avariados from equipamentos where estado='avariado'";
    $result=mysqli_query($conn,$sql);
    return $result;
}
function contarFuncionais($conn){
    $sql="SELECT COUNT(*) AS total_funcionais from equipamentos where estado='Funcional'";
    $result=mysqli_query($conn,$sql);
    return $result;
}
$resultado=contarEquipamentos($conn);
$resultado2=contarAvariados($conn);
$resultado3=contarFuncionais($conn);


?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css">
     <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css">
    <title>Document</title>
     <style>
        *{
        margin: 0;
        padding: 0;
        box-sizing: border-box;
        font-family: "Segoe UI", Arial, sans-serif;
    }
    body{
        background: #F4F6F8;
        display: flex;
        height: 100vh;
        overflow: hidden;
    }

   
    .barra-lateral{
        width: 260px;
        background: #2d558a;
        color: white;
        padding: 25px 20px;
        display: flex;
        flex-direction: column;
    }

    .barra-lateral-titulo{
        font-size: 22px;
        font-weight: bold;
        margin-bottom: 40px;
        text-align: center;
    }

    .menu-lateral a{
        text-decoration: none;
        color: white;
        padding: 14px 15px;
        display: block;
        margin-bottom: 12px;
        background: rgba(255,255,255,0.15);
        border-radius: 6px;
        transition: 0.25s;
        font-size: 15px;
    }

    .menu-lateral a:hover{
        background: #2d558a;
    }

    .area-principal{
        flex: 1;
        display: flex;
        flex-direction: column;
        height: 100%;
        overflow: hidden;
    }

    .cabecalho{
        background: white;
        height: 60px;
        display: flex;
        align-items: center;
        padding: 0 25px;
        border-bottom: 1px solid #D0D4D8;
        justify-content: space-between;
    }

    .cabecalho-titulo{
        font-size: 20px;
        font-weight: bold;
        color: #333333;
    }

    .caixa-usuario{
        background: #2d558a;
        padding: 8px 14px;
        border-radius: 50px;
        color: white;
        font-size: 14px;
        cursor: pointer;
    }

  
    .conteudo{
        padding: 25px;
        height: calc(100vh - 60px);
        overflow-y: auto;
    }

  
    .caixas-info{
        display: flex;
        gap: 20px;
        margin-bottom: 25px;
    }

    .caixa-info{
        flex: 1;
        background: white;
        border: 1px solid #D0D4D8;
        padding: 20px;
        border-radius: 8px;
        box-shadow: 0 1px 3px rgba(0,0,0,0.08);
    }

    .caixa-info h3{
        font-size: 16px;
        color: #333333;
        margin-bottom: 8px;
    }

    .caixa-info span{
        font-size: 26px;
        font-weight: bold;
    }

    table{
        width: 100%;
        border-collapse: collapse;
        background: white;
        border-radius: 6px;
        overflow: hidden;
        box-shadow: 0 1px 3px rgba(0,0,0,0.12);
    }

    th{
    background: #2d558a;
        color: white;
        padding: 11px;
        text-align: left;
        font-size: 15px;
    }

    td{
        padding: 12px;
        font-size: 14px;
        color: #333333;
        border-bottom: 1px solid #D0D4D8;
    }

    tr:hover{
        background: #F0F7FF;
    }

    .estado-funcional{
        color: #34A853;
        font-weight: bold;
    }

    .estado-avariado{
        color: #EA4335;
        font-weight: bold;
    }


    .Btn {

  display: flex;
  align-items: center;
  justify-content: flex-start;
  width: 45px;
  height: 45px;
  border: none;
  border-radius: 50%;
  margin: auto;
    margin-left:20px;
  cursor: pointer;
  position: relative;
  overflow: hidden;
  transition-duration: .3s;
  box-shadow: 2px 2px 10px rgba(0, 0, 0, 0.199);
  background-color: rgb(0, 124, 255);

}

.sign {
  width: 100%;
  transition-duration: .3s;
  display: flex;
  align-items: center;
  justify-content: center;
}

.sign svg {
  width: 17px;
}

.sign svg path {
  fill: white;
}

.text {
  position: absolute;
  right: 0%;
  width: 0%;
  opacity: 0;
  color: white;
  font-size: 1.2em;
  font-weight: 600;
  transition-duration: .3s;
}

.Btn:hover {
  width: 150px;
  border-radius: 40px;
  transition-duration: .3s;
}

.Btn:hover .sign {
  width: 26%;
  transition-duration: .3s;
  padding-left: 10px;
}

.Btn:hover .text {
  opacity: 1;
  width: 70%;
  transition-duration: .3s;
  padding-right: 110px;
}

.Btn:active {
  transform: translate(2px ,2px);
}

 .edit-icon {
    margin-left:5px;
            font-size: 15px; 
            color: #007bff;  
            cursor: pointer;
        }
        .edit-icon:hover {
            color: #0056b3; 
        }

     </style>
</head>
<body>
 
<div class="barra-lateral">
    <h2 class="barra-lateral-titulo">Inventário Escolar</h2>

    <div class="menu-lateral">
        <a href="painel.php"> Painel Inicial</a>
        <a href="registroDeEquipamento.php"> Registar Equipamento</a>
        <a href="equipamentos.php"> Lista de Equipamentos</a>
        <a href="#"> Definições</a>      
        <a href="registro.php">Registrar Administrador</a>
        <br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br>
          <button class="Btn">

        <div class="sign">
            <svg viewBox="0 0 512 512">
            
                <path d="M377.9 105.9L500.7 228.7c7.2 7.2 11.3 17.1 11.3 27.3s-4.1 20.1-11.3 27.3L377.9 406.1c-6.4 6.4-15 9.9-24 9.9c-18.7 0-33.9-15.2-33.9-33.9l0-62.1-128 0c-17.7 0-32-14.3-32-32l0-64c0-17.7 14.3-32 32-32l128 0 0-62.1c0-18.7 15.2-33.9 33.9-33.9c9 0 17.6 3.6 24 9.9zM160 96L96 96c-17.7 0-32 14.3-32 32l0 256c0 17.7 14.3 32 32 32l64 0c17.7 0 32 14.3 32 32s-14.3 32-32 32l-64 0c-53 0-96-43-96-96L0 128C0 75 43 32 96 32l64 0c17.7 0 32 14.3 32 32s-14.3 32-32 32z"></path>
        
            </svg>
        
        </div>
      
        <div class="text"><a href="logout.php">Desconectar</a></div>
    
    </button>   
    </div>
</div>

<div class="area-principal">


    <div class="cabecalho">
        <div class="cabecalho-titulo">Lista de Equipamentos</div>
        <div class="caixa-usuario"><?php echo $_SESSION['nome_do_user'] ?></div>
    </div>

    <div class="conteudo">

        <table>
            <tr>
               <th>nome</th>
                <th>tipo</th>
                 <th>estado</th>
                  <th>local</th>
                     <th>data</th>
                      <th>opções</th>
            </tr>

    <?php if(mysqli_num_rows($result)>0){ ?>
        <?php while($date=mysqli_fetch_assoc($result)){ ?> 
            <tr> 
                <td><?php echo $date["nome"];?></td>
                <td><?php echo $date["tipo"];?></td>
                <td class="estado-funcional">
                    
                    <?php 
                if($date["estado"]=="Funcional"){
                    echo "<span class='estado-funcional' style='color:green'>FUNCIONAL</span>";
               
                }else{
                    echo "<span class='estado-avariado' style='color:red'>AVARIADO</span>";
                }
                ?>
                </td>
                <td><?php echo $date["localização"]; ?></td>
                <td><?php echo $date["data_registro"]; ?></td>   
                 <td id="deletar" id="editar" onclick="executar()"><i class="fa-solid fa-trash" style="color:red;"></i>   <i class="fa-solid fa-pencil edit-icon"></i></td>  
                </tr>
<?php }; ?>
<?php }; ?>

        </table>

    </div>
</div>
</body>
</html>
<script>
    function executar(){
        fetch("deletar.php")
        .then(resposta=> resposta.text())
        .then(dados => {
            document.getElementById("deletar").innerHTML=dados;
            location.reload();
        })
    }
</script>