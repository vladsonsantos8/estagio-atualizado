
<?php
include 'db_conect.php';
session_start();
if(!isset($_SESSION["logado"]) || $_SESSION["logado"]==false){
    header("location:login.php");
exit();
};



function contarEquipamentos($conn){
    $sql="SELECT COUNT(nome) AS total_equipamentos from equipamentos";
    $result=mysqli_query($conn,$sql);
    return $result;
}


function contarAvariados($conn){
    $sql="SELECT COUNT(*) AS total_avariados from equipamentos where estado='avariado'";
    $result=mysqli_query($conn,$sql);
    return $result;
}
function contarFuncionais($conn){
    $sql="SELECT COUNT(*) AS total_funcionais from equipamentos where estado='Funcional'";
    $result=mysqli_query($conn,$sql);
    return $result;
}
$resultado=contarEquipamentos($conn);
$resultado2=contarAvariados($conn);
$resultado3=contarFuncionais($conn);


$sql = "
SELECT 
  MONTH(data_registro) AS mes,
  COUNT(*) AS total
FROM equipamentos
GROUP BY MONTH(data_registro)
ORDER BY mes
";

$resultado4 = mysqli_query($conn, $sql);

$meses = [];
$totais = [];

$mapaMeses = [
  1=>"Jan",2=>"Fev",3=>"Mar",4=>"Abr",5=>"Mai",6=>"Jun",
  7=>"Jul",8=>"Ago",9=>"Set",10=>"Out",11=>"Nov",12=>"Dez"
];

while ($row = mysqli_fetch_assoc($resultado4)) {
    if(!empty($row["mes"]) && isset($mapaMeses[$row["mes"]])){
  $meses[] = $mapaMeses[$row['mes']];
  $totais[] = $row['total'];
}
}

?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
     <style>

    .chart-container {
      width: 80%;
      margin:20px auto;
    }
    #line-cart{
        width:100%;
        height:400px;
    }
   

        *{
        margin: 0;
        padding: 0;
        box-sizing: border-box;
        font-family: "Segoe UI", Arial, sans-serif;
    }
    body{
        background: #F4F6F8;
        display: flex;
        height: 100vh;
        overflow: hidden;
    }

   
    .barra-lateral{
        width: 260px;
        background: #2d558a;
        color: white;
        padding: 25px 20px;
        display: flex;
        flex-direction: column;
    }

    .barra-lateral-titulo{
        font-size: 22px;
        font-weight: bold;
        margin-bottom: 40px;
        text-align: center;
    }

    .menu-lateral a{
        text-decoration: none;
        color: white;
        padding: 14px 15px;
        display: block;
        margin-bottom: 12px;
        background: rgba(255,255,255,0.15);
        border-radius: 6px;
        transition: 0.25s;
        font-size: 15px;
    }

    .menu-lateral a:hover{
        background: #2d558a;
    }

    .area-principal{
        flex: 1;
        display: flex;
        flex-direction: column;
        height: 100%;
        overflow: hidden;
    }

    .cabecalho{
        background: white;
        height: 60px;
        display: flex;
        align-items: center;
        padding: 0 25px;
        border-bottom: 1px solid #D0D4D8;
        justify-content: space-between;
    }

    .cabecalho-titulo{
        font-size: 20px;
        font-weight: bold;
        color: #333333;
    }

    .caixa-usuario{
        background: #2d558a;
        padding: 8px 14px;
        border-radius: 50px;
        color: white;
        font-size: 14px;
        cursor: pointer;
    }

  
    .conteudo{
        padding: 25px;
        height: calc(100vh - 60px);
        overflow-y: auto;
    }

  
    .caixas-info{
        display: flex;
        gap: 20px;
        margin-bottom: 25px;
    }

    .caixa-info{
        flex: 1;
        background: white;
        border: 1px solid #D0D4D8;
        padding: 20px;
        border-radius: 8px;
        box-shadow: 0 1px 3px rgba(0,0,0,0.08);
    }

    .caixa-info h3{
        font-size: 16px;
        color: #333333;
        margin-bottom: 8px;
    }

    .caixa-info span{
        font-size: 26px;
        font-weight: bold;
    }

    .estado-funcional{
        color: #34A853;
        font-weight: bold;
    }

    .estado-avariado{
        color: #EA4335;
        font-weight: bold;
    }
    
    .Btn {

  display: flex;
  align-items: center;
  justify-content: flex-start;
  width: 45px;
  height: 45px;
  border: none;
  border-radius: 50%;
  margin: auto;
    margin-left:20px;
  cursor: pointer;
  position: relative;
  overflow: hidden;
  transition-duration: .3s;
  box-shadow: 2px 2px 10px rgba(0, 0, 0, 0.199);
  background-color: rgb(0, 124, 255);

}

.sign {
  width: 100%;
  transition-duration: .3s;
  display: flex;
  align-items: center;
  justify-content: center;
}

.sign svg {
  width: 17px;
}

.sign svg path {
  fill: white;
}

.text {
  position: absolute;
  right: 0%;
  width: 0%;
  opacity: 0;
  color: white;
  font-size: 1.2em;
  font-weight: 600;
  transition-duration: .3s;
}

.Btn:hover {
  width: 150px;
  border-radius: 40px;
  transition-duration: .3s;
}

.Btn:hover .sign {
  width: 26%;
  transition-duration: .3s;
  padding-left: 10px;
}

.Btn:hover .text {
  opacity: 1;
  width: 70%;
  transition-duration: .3s;
  padding-right: 110px;
}

.Btn:active {
  transform: translate(2px ,2px);
}


     </style>
</head>
<body>
 
<div class="barra-lateral">
    <h2 class="barra-lateral-titulo">Inventário Escolar</h2>
<div class="menu-lateral">
        <a href="painel.php"> Painel Inicial</a>
        <a href="registroDeEquipamento.php"> Registar Equipamento</a>
        <a href="equipamentos.php"> Lista de Equipamentos</a>
        <a href="definição.php"> Definições</a>      
        <a href="registro.php">Registrar Administrador</a>
        <a href="logout.php">Desconectar</a>
    </div>
</div>

<div class="area-principal">

    
    <div class="cabecalho">
        <div class="cabecalho-titulo">Estatisticas</div>
        <div class="caixa-usuario"><?php echo $_SESSION['nome_do_user'] ?></div>
    </div>

    <div class="conteudo">

     
        <div class="caixas-info">
            <div class="caixa-info">
                <h3>Total de Equipamentos</h3>
                 <?php if(mysqli_num_rows($resultado)>0){ ?>
                <?php while($date=mysqli_fetch_assoc($resultado)){?>
                <span><?php echo $date["total_equipamentos"];?></span>
                <?php }?>
                  <?php }?>
            </div>
            <div class="caixa-info">
                <h3>Funcionais</h3>
                  <?php if(mysqli_num_rows($resultado3)>0){ ?>
                <?php while($date=mysqli_fetch_assoc($resultado3)){?>
                <span style="color:#34A853;"><?php echo $date["total_funcionais"]; ?></span>
                <?php }?>
                  <?php }?>
            </div>
            <div class="caixa-info">
                <h3>Avariados</h3>
                <?php if(mysqli_num_rows($resultado2)>0){ ?>
                <?php while($date=mysqli_fetch_assoc($resultado2)){?>
                <span style="color:#EA4335;"><?php echo $date["total_avariados"]; ?></span>
                <?php }?>
                  <?php }?>
            </div>
        </div>

<div class="chart-container">
  <canvas id="line-cart"></canvas>
</div>

</div>

<script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
<script>
  const data = {
    labels: <?php echo json_encode($meses); ?>,
    datasets: [{
      label: "Equipamentos Registrados",
      data: <?php echo json_encode($totais); ?>,
      backgroundColor: "rgba(54, 162, 235, 0.2)",
      borderColor: "rgba(54, 162, 235, 1)",
      borderWidth: 3,
      borderRadius:5,
      pointBackgroundColor:"#2563eb",
      tension:0.4,
      fill: true
    }]
  };

  const options = {
    responsive: true,
    scales: {
      y: [{
        ticks:{
        beginAtZero: true
      }
    }]
}
  };
  const ctx = document.getElementById("line-cart").getContext("2d");
  new Chart(ctx, {
    type: "line",
    data: data,
    options: options
  });
</script>
</body>
</html>