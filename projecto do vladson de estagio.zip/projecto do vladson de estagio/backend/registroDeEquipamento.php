<?php 
include "db_conect.php";
session_start();
if(!isset($_SESSION["logado"]) || $_SESSION["logado"]==false){
    header("location:login.php");
exit();
}
?>
<?php
if(isset($_POST['btn'])){

    if($_SESSION["logado"]){
        $tipo = mysqli_real_escape_string($conn,($_POST['tipo']));
$estado = mysqli_real_escape_string($conn,($_POST['estado']));
$local = mysqli_real_escape_string($conn,($_POST['local']));
$nome = mysqli_real_escape_string($conn,($_POST['nome']));

$sql = "INSERT INTO equipamentos VALUES(DEFAULT,'$nome','$tipo',now(),'$estado','$local')";
$result=mysqli_query($conn,$sql);
    }


$sql="select id,nome from users";
$result=mysqli_query($conn,$sql);

        if(mysqli_num_rows($result)>0){
            $dados=mysqli_fetch_assoc($result);

            $_SESSION['adm'] = true;
            $_SESSION['id_usuario'] = $dados['id'];
            $_SESSION['nome_do_user']=$dados['nome'];
            
        }else{
            header("location:registro.php");
            echo"<li>ERRO</li>";
        };
};
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Registro Adim</title>
    <style>
        *{
        margin: 0;
        padding: 0;
        box-sizing: border-box;
        font-family: "Segoe UI", Arial, sans-serif;
    }
        body{
    display: flex;
    align-items: center;
    justify-content: center;
    height: 100vh;
    overflow:hidden;
    flex-direction: row;
    font-family: sans-serif;
    background-color:rgb(255, 255, 255);
}

    .barra-lateral{
        width: 260px;
        height: 100%;
        background: #2d558a;
        color: white;
        padding: 25px 20px;
        display: flex;
        flex-direction: column;
    }

    .barra-lateral-titulo{
        font-size: 22px;
        font-weight: bold;
        margin-bottom: 40px;
        text-align: center;
    }

    .menu-lateral a{
        text-decoration: none;
        color: white;
        padding: 14px 15px;
        display: block;
        margin-bottom: 12px;
        background: rgba(255,255,255,0.15);
        border-radius: 6px;
        transition: 0.25s;
        font-size: 15px;
    }

    .menu-lateral a:hover{
        background: #2d558a;
    }

    .area-principal{
        flex: 1;
        display: flex;
        flex-direction: column;
        height: 100%;
        overflow: hidden;
    }

    .cabecalho{
        background: white;
        height: 60px;
        display: flex;
        align-items: center;
        padding: 0 25px;
        border-bottom: 1px solid #D0D4D8;
        justify-content: space-between;
    }

    .cabecalho-titulo{
        font-size: 20px;
        font-weight: bold;
        color: #333333;
    }

    .caixa-usuario{
        background: #2d558a;
        padding: 8px 14px;
        border-radius: 50px;
        color: white;
        font-size: 14px;
        cursor: pointer;
    }

  
    .conteudo{
        padding: 25px;
        height: calc(100vh - 60px);
        overflow-y: auto;
        display: flex;
        align-items: center;    
        justify-content: center;
    }


form{
    background-color:rgb(255, 255, 255);
   border-radius: 100px;
    width: 700px;
   box-shadow:0px 25px 50px -12px #6e749b40;
    height: 500px;
    margin: 7px;
    padding:20px 20px 20px 20px;
    border-radius: 1px;
    display: flex;
    flex-direction: column;
    gap: 10px;
    justify-content: center;
    animation:subir 3s ;
    
}
h1{
    align-self: center;
    font-weight: bolder;
    font-size: 40px;
}
span{
    color: rgb(30, 65, 173);
}
input{
    border: 2px solid;
    border-radius: 1px;
    padding: 20px;
}
input:hover{
    border: solid 2px rgb(30, 65, 173);
}
button{
   
   border-radius: 1px; 
   outline: none;
   padding: 20px;
   font-weight: bolder;
   color: white;
   background-color: rgb(30, 65, 173);
}
button:active{
    background-color: white;
    color: rgb(30, 65, 173);
}
#div1{
    display:flex;
    align-self:center;
width:300px;
}
#div2{
    display:flex;
    align-self:center; 
width:50%;
}

    .Btn {

  display: flex;
  align-items: center;
  justify-content: flex-start;
  width: 45px;
  height: 45px;
  border: none;
  border-radius: 50%;
  margin: auto;
    margin-left:20px;
  cursor: pointer;
  position: relative;
  overflow: hidden;
  transition-duration: .3s;
  box-shadow: 2px 2px 10px rgba(0, 0, 0, 0.199);
  background-color: rgb(0, 124, 255);

}

.sign {
  width: 100%;
  transition-duration: .3s;
  display: flex;
  align-items: center;
  justify-content: center;
}

.sign svg {
  width: 17px;
}

.sign svg path {
  fill: white;
}

.text {
  position: absolute;
  right: 0%;
  width: 0%;
  opacity: 0;
  color: white;
  font-size: 1.2em;
  font-weight: 600;
  transition-duration: .3s;
}

.Btn:hover {
  width: 150px;
  border-radius: 40px;
  transition-duration: .3s;
}

.Btn:hover .sign {
  width: 26%;
  transition-duration: .3s;
  padding-left: 10px;
}

.Btn:hover .text {
  opacity: 1;
  width: 70%;
  transition-duration: .3s;
  padding-right: 110px;
}

.Btn:active {
  transform: translate(2px ,2px);
}


    </style>
</head>
<html>
<body>
<div class="barra-lateral">
    <h2 class="barra-lateral-titulo">Inventário Escolar</h2>

  <div class="menu-lateral">
        <a href="painel.php"> Painel Inicial</a>
        <a href="registroDeEquipamento.php"> Registar Equipamento</a>
        <a href="equipamentos.php"> Lista de Equipamentos</a>
        <a href="#"> Definições</a>      
        <a href="registro.php">Registrar Administrador</a>
        <br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br>
          <button class="Btn">

        <div class="sign">
            <svg viewBox="0 0 512 512">
            
                <path d="M377.9 105.9L500.7 228.7c7.2 7.2 11.3 17.1 11.3 27.3s-4.1 20.1-11.3 27.3L377.9 406.1c-6.4 6.4-15 9.9-24 9.9c-18.7 0-33.9-15.2-33.9-33.9l0-62.1-128 0c-17.7 0-32-14.3-32-32l0-64c0-17.7 14.3-32 32-32l128 0 0-62.1c0-18.7 15.2-33.9 33.9-33.9c9 0 17.6 3.6 24 9.9zM160 96L96 96c-17.7 0-32 14.3-32 32l0 256c0 17.7 14.3 32 32 32l64 0c17.7 0 32 14.3 32 32s-14.3 32-32 32l-64 0c-53 0-96-43-96-96L0 128C0 75 43 32 96 32l64 0c17.7 0 32 14.3 32 32s-14.3 32-32 32z"></path>
        
            </svg>
        
        </div>
      
        <div class="text"><a href="logout.php">Desconectar</a></div>
    
    </button>   
    </div>
</div>

<div class="area-principal">

    
    <div class="cabecalho">
        <div class="cabecalho-titulo">Sistema de Registo de Equipamentos</div>
        <div class="caixa-usuario"><?php echo $_SESSION['nome_do_user'] ?></div>
    </div>

    <div class="conteudo">
 <form method="post" action="<?php echo $_SERVER['PHP_SELF'];?>">

    <label for="">nome do Equipamento</label>
    <input type="text" name="nome" placeholder="nome" required>

    <label for="">Tipo de equipamento</label>
    <input type="text" name="tipo"  placeholder="tipo" required>

    <label for="">Estado</label>
    <input type="text" name="estado" placeholder="Funcional/Avariado" required>

     <label for="">Local</label>
    <input type="text" name="local" placeholder="localizaçaõ" required>

    <button type="submit" name="btn">ADD</button>
   </form>
    </div>
</body>
</html>