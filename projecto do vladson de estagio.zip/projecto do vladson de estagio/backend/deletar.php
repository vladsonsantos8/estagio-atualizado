<?php
include 'db_conect.php';
session_start();


function deletar($conn){
if(isset($_SESSION["logado"])){
    $sql="SELECT id,nome,tipo,data_registro,estado,localização FROM Equipamentos ORDER BY id DESC";
    $result=mysqli_query($conn,$sql);
}
  if(mysqli_num_rows($result)>0){
    $dados=mysqli_fetch_assoc($result);
    $id=$dados["id"];
    $sql="DELETE from equipamentos WHERE id=$id";
    $result=mysqli_query($conn,$sql);
    return $result;
  }
    
}
$resultado4=deletar($conn);



?>