
<?php
include 'db_conect.php';
session_start();
if(!isset($_SESSION["logado"]) || $_SESSION["logado"]==false){
    header("location:login.php");
exit();
};


  $sql = "SELECT id,nome,email FROM users";
            $result = mysqli_query($conn, $sql);
        if(mysqli_num_rows($result) > 0)
                    $dados = mysqli_fetch_array($result);
                $_SESSION['logado'] = true;
                $_SESSION['id_usuario'] = $dados['id'];
                $_SESSION['nome_do_user']=$dados['nome'];
                 $_SESSION['email_user']=$dados['email'];


?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
     <style>


        *{
        margin: 0;
        padding: 0;
        box-sizing: border-box;
        font-family: "Segoe UI", Arial, sans-serif;
    }
    body{
        background: #F4F6F8;
        display: flex;
        height: 100vh;
        overflow: hidden;
    }

   
    .barra-lateral{
        width: 260px;
        background: #2d558a;
        color: white;
        padding: 25px 20px;
        display: flex;
        flex-direction: column;
    }

    .barra-lateral-titulo{
        font-size: 22px;
        font-weight: bold;
        margin-bottom: 40px;
        text-align: center;
    }

    .menu-lateral a{
        text-decoration: none;
        color: white;
        padding: 14px 15px;
        display: block;
        margin-bottom: 12px;
        background: rgba(255,255,255,0.15);
        border-radius: 6px;
        transition: 0.25s;
        font-size: 15px;
    }

    .menu-lateral a:hover{
        background: #2d558a;
    }

    .area-principal{
        flex: 1;
        display: flex;
        flex-direction: column;
        height: 100%;
        overflow: hidden;
    }

    .cabecalho{
        background: white;
        height: 60px;
        display: flex;
        align-items: center;
        padding: 0 25px;
        border-bottom: 1px solid #D0D4D8;
        justify-content: space-between;
    }

    .cabecalho-titulo{
        font-size: 20px;
        font-weight: bold;
        color: #333333;
    }

    .caixa-usuario{
        background: #2d558a;
        padding: 8px 14px;
        border-radius: 50px;
        color: white;
        font-size: 14px;
        cursor: pointer;
    }

  
    .conteudo{
        width: 100%;
        height: 100%;
    }

  
    .caixas-info{
        display: flex;
        gap: 20px;
        margin-bottom: 25px;
    }

    .caixa-info{
        flex: 1;
        background: white;
        border: 1px solid #D0D4D8;
        padding: 20px;
        border-radius: 8px;
        box-shadow: 0 1px 3px rgba(0,0,0,0.08);
    }

    .caixa-info h3{
        font-size: 16px;
        color: #333333;
        margin-bottom: 8px;
    }

    .caixa-info span{
        font-size: 26px;
        font-weight: bold;
    }

  
.sign svg {
  width: 17px;
}

.sign svg path {
  fill: white;
}




.cartao-email {
  display: flex;
  align-items: center;
  gap: 16px;
  padding: 20px 24px;
  border-radius: 16px;
  transition: all 0.3s ease;
  width: 60%;
  margin-top: 50px;
  margin-left: 50px;
}


.cartao-professor {
  background: linear-gradient(145deg, #ffffff 0%, #f8f9ff 100%);
  box-shadow: 0 10px 40px rgba(0, 0, 0, 0.15);
  border: 2px solid rgba(255, 255, 255, 0.8);
}



.avatar-email {
  width: 56px;
  height: 56px;
  border-radius: 50%;
  display: flex;
  align-items: center;
  justify-content: center;
  font-size: 1.4rem;
  font-weight: 700;
  color: #ffffffff;
  flex-shrink: 0;
}

.avatar-professor {
  width: 64px;
  height: 64px;
  background: #2d558a;
  font-size: 1.6rem;
 
}


.conteudo-email {
  flex: 1;
  min-width: 0;
  
}

.nome-email {
  font-size: 1.1rem;
  font-weight: 600;
  color: #2d3748;
  margin-bottom: 4px;
}

.endereco-email {
  font-size: 0.95rem;
  color: #667eea;
  margin-bottom: 4px;
  word-break: break-all;
}

.departamento-email {
  font-size: 0.85rem;
  color: #718096;
  font-style: italic;
}


.botao-acao {
  background: #2d558a;
  color: #ffffff;
  border: none;
  padding: 10px 20px;
  border-radius: 25px;
  font-size: 0.95rem;
  font-weight: 600;
  cursor: pointer;
  transition: all 0.3s ease;
 
}

.botao-acao:hover {
  transform: scale(1.05);
 
}



        .fundo-modal {
        display: none; /* Oculto por padrão */
        position: fixed;
        top: 0; left: 0;
        width: 100%; height: 100%;
        background: rgba(0, 0, 0, 0.6);
        backdrop-filter: blur(3px);
        justify-content: center;
        align-items: center;
        z-index: 1000;
    }

    /* ===== Caixa do modal ===== */
    .caixa-modal {
        position: relative;
        left: 50%;top: 50%;
        transform: translate(-50%, -50%);
        background: white;
        padding: 20px;
        border-radius: 10px;
        max-width: 400px;
        width: 90%;
        box-shadow: 0 5px 15px rgba(0,0,0,0.3);
        animation: aparecer 0.3s ease;
    }

    /* ===== Cabeçalho do modal ===== */
    .cabecalho-modal {
        display: flex;
        justify-content: space-between;
        align-items: center;
        border-bottom: 1px solid #ddd;
        padding-bottom: 10px;
    }
    .cabecalho-modal h2 {
        margin: 0;
        font-size: 20px;
    }
    .botao-fechar {
       height:40px;
       margin-left: 40px;
        background: #1e27e1ff;
        color: white;
        border: none;
        border-radius: 20px;
        width: 150px;
        cursor: pointer;
        font-size: 16px;
        transition: background 0.3s;
    }
    .botao-fechar:hover {
        color: #f5f3f3ff;
        background: #1e28e1a7;
    }

    /* ===== Corpo do modal ===== */
    .corpo-modal {
        margin-top: 15px;
        font-size: 16px;
        color: #333;
        padding: 100px;
    }

    /* ===== Animação ===== */
    @keyframes aparecer {
        from { opacity: 0; transform: translateY(-20px); }
        to { opacity: 1; transform: translateY(0); }
    }
     .salvarB  {
        height:40px;
        margin-left: 10px;
        background: #1114b7bd;
        color: white;
        border: none;
        border-radius: 20px;
        width: 150px;
        cursor: pointer;
        font-size: 16px;
        transition: background 0.3s;
    }
      .salvarB  {
       background: #0f11bd83;  
    }
    .botao-fechar {
        height:40px;
        background: #e01d1dff;
        color: white;
        border: none;
        border-radius: 20px;
        width: 150px;
        cursor: pointer;
        font-size: 16px;
        transition: background 0.3s;
    }
    .botao-fechar:hover {
       background: #e01d1d83;  
    }
    input{
    border: 2px solid;
    border-radius: 1px;
    padding: 20px;
    width: 350px;
}
input:hover{
    border: solid 2px rgb(30, 65, 173);
}
form{
    width: 100%;
    height: 100%;
    display: flex;
    align-items: center;
    justify-content: center;
    flex-direction: column;
    gap: 10px;
}


     </style>
</head>
<body>
    
<div class="fundo-modal" id="fundoModal">
    <div class="caixa-modal">
        <div class="cabecalho-modal">
            <h2>Editar Informações</h2>
        </div>
        <div class="corpo-modal">
          <form method="post" action="editarInfoUser.php">
 <div id="div1">
        <div id="div2">
            <img src="logo.png" alt="">
        </div>
</div>
    
    <input type="text" name="nome" placeholder="nome" required>

    
    <input type="email" name="email" placeholder="email" required>


    <input type="password" name="pass"  placeholder="password" required>

    <input type="password" name="passConfirm"  placeholder="new password" required>
    <?php
    if(isset($_SESSION["erros"])){
        foreach($_SESSION["erros"] as $erro){
            echo $erro;
        }
        unset($_SESSION['erros']);
    }
    ?>
    <div style="display: flex; flex-direction:row;">
    <button name="salvar" class="salvarB" type="submit">salvar</button>
        <button class="botao-fechar" id="fecharModal" type="button">voltar</button>
    </div>
    
   </form>
        </div>
        
       
    </div>
</div>
 
<div class="barra-lateral">
    <h2 class="barra-lateral-titulo">Inventário Escolar</h2>
<div class="menu-lateral">
        <a href="painel.php"> Painel Inicial</a>
        <a href="registroDeEquipamento.php"> Registar Equipamento</a>
        <a href="equipamentos.php"> Lista de Equipamentos</a>
        <a href="definição.php"> Definições</a>      
        <a href="registro.php">Registrar Administrador</a>
        <br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br>
          <button class="Btn">

        <div class="sign">
            <svg viewBox="0 0 512 512">
            
                <path d="M377.9 105.9L500.7 228.7c7.2 7.2 11.3 17.1 11.3 27.3s-4.1 20.1-11.3 27.3L377.9 406.1c-6.4 6.4-15 9.9-24 9.9c-18.7 0-33.9-15.2-33.9-33.9l0-62.1-128 0c-17.7 0-32-14.3-32-32l0-64c0-17.7 14.3-32 32-32l128 0 0-62.1c0-18.7 15.2-33.9 33.9-33.9c9 0 17.6 3.6 24 9.9zM160 96L96 96c-17.7 0-32 14.3-32 32l0 256c0 17.7 14.3 32 32 32l64 0c17.7 0 32 14.3 32 32s-14.3 32-32 32l-64 0c-53 0-96-43-96-96L0 128C0 75 43 32 96 32l64 0c17.7 0 32 14.3 32 32s-14.3 32-32 32z"></path>
        
            </svg>
        
        </div>
      
        <div class="text"><a href="logout.php">Desconectar</a></div>
    
    </button>   
    </div>
</div>

<div class="area-principal">

    
    <div class="cabecalho">
        <div class="cabecalho-titulo">Definições do user</div>
        <div class="caixa-usuario"><?php echo $_SESSION['nome_do_user'] ?></div>
    </div>
   

    <div class="conteudo">
<div class="cartao-email cartao-professor">
            <div class="avatar-email avatar-professor"><?php echo $_SESSION["nome_do_user"][0];?></div>
            <div class="conteudo-email">
              <div class="nome-email"><?php echo $_SESSION["nome_do_user"]; ?></div>
              <div class="endereco-email"><?php echo $_SESSION['email_user'];?></div>
            </div>
            <button class="botao-acao" id="editar" ><a style="text-decoration: none; color:#d4edda;">editar</a></button>
          </div>
     
        </div>
       


</body>
</html>
<script>
    const botaoAbrir = document.getElementById('editar');
    const botaoFechar = document.getElementById('fecharModal');
    const fundoModal = document.getElementById('fundoModal');
    
   

    // Abre o modal
    botaoAbrir.addEventListener('click', () => {
        fundoModal.style.display = 'block'; 
        
    });

    // Fecha o modal
    botaoFechar.addEventListener('click', () => {
        fundoModal.style.display = 'none';
    });

    // Fecha clicando fora da caixa
    window.addEventListener('click', (evento) => {
        if (evento.target === fundoModal) {
            fundoModal.style.display = 'none';
        }
    });
</script>
 <?php if(isset($_SESSION['erros'])){ ?>
<script>
    document.getElementById('fundoModal').style.display = 'block';
</script>
<?php }; ?>