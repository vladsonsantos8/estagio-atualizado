<?php
$servername="localhost";
$username="root";
$password="";
$db_name="adms";

$conn=mysqli_connect($servername,$username,$password,$db_name);
if(mysqli_connect_error()){
    echo"falha na conecção".mysqli_connect_error();
}
?>