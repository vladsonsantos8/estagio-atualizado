<?php
session_start();
include 'db_conect.php';

if(isset($_POST['salvar'])){

    $erros = [];

    $nome  = mysqli_real_escape_string($conn, $_POST['nome']);
    $email = mysqli_real_escape_string($conn, $_POST['email']);
    $senha = mysqli_real_escape_string($conn, $_POST['pass']);
    $senhaConfirm = mysqli_real_escape_string($conn, $_POST['passConfirm']);

  
    if($senha !== $senhaConfirm){
        $erros[] = "As senhas não coincidem";
    }

  
    if(!empty($erros)){
        $_SESSION['erros'] = $erros;
        header("Location: definição.php");
        exit();
    }

    $id = $_SESSION['id_usuario'];

    $sql = "UPDATE users 
            SET nome='$nome', email='$email', senha='$senha' 
            WHERE id='$id'";

    if(mysqli_query($conn, $sql)){

        $_SESSION['nome_do_user'] = $nome;
        $_SESSION['email_user']  = $email;

        header("Location: definição.php");
        exit();
    } else {
        $_SESSION['erros'] = ["Erro ao atualizar dados"];
        header("Location: definição.php");
        exit();
    }
}
?>

